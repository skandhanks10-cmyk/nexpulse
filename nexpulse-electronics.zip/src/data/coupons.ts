import { Coupon } from '../types';

export const COUPON_DATABASE: Coupon[] = [
  {
    code: 'SAVE10',
    description: '10% instant discount on orders above ₹1,000',
    type: 'percentage',
    value: 10,
    minOrderValue: 1000,
    expiryDate: '2028-12-31T23:59:59Z',
    isActive: true,
  },
  {
    code: 'SAVE500',
    description: 'Flat ₹500 instant discount on orders above ₹5,000',
    type: 'fixed',
    value: 500,
    minOrderValue: 5000,
    expiryDate: '2028-12-31T23:59:59Z',
    isActive: true,
  },
  {
    code: 'WELCOME15',
    description: '15% discount up to ₹1,000 on orders above ₹500',
    type: 'percentage',
    value: 15,
    minOrderValue: 500,
    maxDiscount: 1000,
    expiryDate: '2028-12-31T23:59:59Z',
    isActive: true,
  },
  {
    code: 'EXPIRED20',
    description: 'Special 20% off summer blowout (Expired on 2024-01-01)',
    type: 'percentage',
    value: 20,
    minOrderValue: 1500,
    maxDiscount: 2000,
    expiryDate: '2024-01-01T00:00:00Z', // Officially expired
    isActive: true,
  },
  {
    code: 'TECH100',
    description: 'Flat ₹100 off on gaming gear and accessories above ₹1,500',
    type: 'fixed',
    value: 100,
    minOrderValue: 1500,
    expiryDate: '2028-12-31T23:59:59Z',
    isActive: true,
  }
];
