import { Product } from '../types';

export const SAMPLE_PRODUCTS: Product[] = [
  // --- Smartphones ---
  {
    id: 'prod-phone-1',
    name: 'Apex Phone 16 Pro Max',
    category: 'Smartphones',
    brand: 'Apex',
    description: 'Flagship smartphone featuring aerospace-grade titanium chassis, 48MP triple-lens optical system, and next-gen 3nm neural bionic processor with all-day battery life.',
    price: 89999,
    discountPrice: 79999,
    rating: 4.8,
    reviewsCount: 342,
    stockQuantity: 18,
    inStock: true,
    isFeatured: true,
    isBestSeller: true,
    releaseDate: '2026-09-15',
    thumbnailGradient: 'from-slate-900 to-indigo-950',
    images: [
      'https://images.unsplash.com/photo-1592750475338-74b7b21085ab?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?auto=format&fit=crop&w=800&q=80',
    ],
    variants: [
      { id: 'var-phone-1-128', name: '128GB Titanium Silver', type: 'storage', priceModifier: 0, stockQuantity: 8 },
      { id: 'var-phone-1-256', name: '256GB Natural Titanium', type: 'storage', priceModifier: 10000, stockQuantity: 6 },
      { id: 'var-phone-1-512', name: '512GB Space Black', type: 'storage', priceModifier: 20000, stockQuantity: 4 },
    ],
    specifications: {
      'Display': '6.7-inch Super Retina XDR OLED, 120Hz ProMotion',
      'Processor': 'A18 Pro Hexa-Core (3nm)',
      'Camera': '48MP Main + 48MP Ultra-Wide + 12MP 5x Telephoto',
      'Battery': '4,441 mAh with 30W Fast Charging & Qi2 Wireless',
      'OS': 'ApexOS 18',
      'Weight': '221 grams'
    }
  },
  {
    id: 'prod-phone-2',
    name: 'Pulse Nord Neo 5G',
    category: 'Smartphones',
    brand: 'Pulse',
    description: 'Sleek mid-range powerhouse with 120Hz AMOLED fluid display, 64MP OIS primary sensor, and ultra-fast 80W SuperVOOC wired charging.',
    price: 28999,
    discountPrice: 24999,
    rating: 4.5,
    reviewsCount: 198,
    stockQuantity: 25,
    inStock: true,
    isBestSeller: true,
    releaseDate: '2026-06-10',
    thumbnailGradient: 'from-emerald-950 to-teal-900',
    images: [
      'https://images.unsplash.com/photo-1598327105666-5b89351aff97?auto=format&fit=crop&w=800&q=80',
    ],
    variants: [
      { id: 'var-phone-2-8gb', name: '8GB RAM + 128GB Storage (Glacier Blue)', type: 'storage', priceModifier: 0, stockQuantity: 15 },
      { id: 'var-phone-2-12gb', name: '12GB RAM + 256GB Storage (Midnight Onyx)', type: 'storage', priceModifier: 3000, stockQuantity: 10 },
    ],
    specifications: {
      'Display': '6.67-inch FHD+ 120Hz Flow AMOLED',
      'Processor': 'MediaTek Dimensity 8200-Ultra (4nm)',
      'Camera': '64MP OIS + 8MP Ultra-Wide + 2MP Macro',
      'Battery': '5,000 mAh with 80W Charger in Box',
      'Weight': '184 grams'
    }
  },
  {
    id: 'prod-phone-3',
    name: 'Galaxy Ultra Z9 Fold',
    category: 'Smartphones',
    brand: 'Samsung',
    description: 'Transformative dual-screen foldable smartphone with armor aluminum frame, S-Pen stylus support, and pro-grade multi-tasking workspace.',
    price: 129999,
    discountPrice: 114999,
    rating: 4.7,
    reviewsCount: 88,
    stockQuantity: 7,
    inStock: true,
    releaseDate: '2026-08-01',
    thumbnailGradient: 'from-purple-950 to-slate-900',
    images: [
      'https://images.unsplash.com/photo-1580910051074-3eb694886505?auto=format&fit=crop&w=800&q=80',
    ],
    variants: [
      { id: 'var-phone-3-256', name: '256GB Phantom Black', type: 'storage', priceModifier: 0, stockQuantity: 4 },
      { id: 'var-phone-3-512', name: '512GB Silver Shadow', type: 'storage', priceModifier: 12000, stockQuantity: 3 },
    ],
    specifications: {
      'Main Screen': '7.6-inch Dynamic AMOLED 2X, 120Hz Adaptive',
      'Cover Screen': '6.3-inch Dynamic AMOLED 2X',
      'Processor': 'Snapdragon 8 Gen 3 for Galaxy',
      'Durability': 'IP48 Water Resistant, Gorilla Glass Armor',
      'Weight': '239 grams'
    }
  },
  {
    id: 'prod-phone-4',
    name: 'ZenPixel 8a Pure',
    category: 'Smartphones',
    brand: 'Zenith',
    description: 'Computational photography benchmark with custom Tensor G3 chip, AI Magic Eraser, and seven years of guaranteed software updates.',
    price: 43999,
    discountPrice: 38999,
    rating: 4.6,
    reviewsCount: 154,
    stockQuantity: 12,
    inStock: true,
    releaseDate: '2026-05-20',
    thumbnailGradient: 'from-blue-950 to-slate-900',
    images: [
      'https://images.unsplash.com/photo-1574944985070-8f3ebc6b79d2?auto=format&fit=crop&w=800&q=80',
    ],
    variants: [
      { id: 'var-phone-4-bay', name: '128GB Bay Blue', type: 'color', priceModifier: 0, stockQuantity: 7 },
      { id: 'var-phone-4-obs', name: '128GB Obsidian', type: 'color', priceModifier: 0, stockQuantity: 5 },
    ],
    specifications: {
      'Display': '6.1-inch Actua OLED, 120Hz',
      'Camera': '64MP Quad PD wide + 13MP ultrawide',
      'Security': 'Titan M2 security co-processor',
      'Battery': '4,492 mAh'
    }
  },

  // --- Laptops ---
  {
    id: 'prod-laptop-1',
    name: 'NovaBook Pro 16 M3 Max',
    category: 'Laptops',
    brand: 'Nova',
    description: 'Engineering marvel featuring 16-core CPU, 40-core GPU, Liquid Retina XDR mini-LED display with 1600 nits peak brightness, and 22-hour battery life.',
    price: 169999,
    discountPrice: 149999,
    rating: 4.9,
    reviewsCount: 220,
    stockQuantity: 10,
    inStock: true,
    isFeatured: true,
    releaseDate: '2026-01-12',
    thumbnailGradient: 'from-slate-900 to-zinc-900',
    images: [
      'https://images.unsplash.com/photo-1517336714731-489689fd1ca8?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1611186871348-b1ce696e52c9?auto=format&fit=crop&w=800&q=80',
    ],
    variants: [
      { id: 'var-laptop-1-36gb', name: '36GB Unified Memory / 1TB SSD', type: 'storage', priceModifier: 0, stockQuantity: 6 },
      { id: 'var-laptop-1-48gb', name: '48GB Unified Memory / 2TB SSD', type: 'storage', priceModifier: 25000, stockQuantity: 4 },
    ],
    specifications: {
      'Screen': '16.2-inch Liquid Retina XDR (3456 x 2234), 120Hz ProMotion',
      'Processor': 'M3 Max with 16-core CPU & 40-core GPU',
      'Ports': '3x Thunderbolt 4, HDMI 2.1, SDXC card slot, MagSafe 3',
      'Battery': '100-watt-hour lithium-polymer with 140W USB-C adapter',
      'Weight': '2.16 kg'
    }
  },
  {
    id: 'prod-laptop-2',
    name: 'AeroBook Air 14 Feather',
    category: 'Laptops',
    brand: 'Nova',
    description: 'Ultra-portable fanless aluminum notebook weighing just 1.15kg. Whisper-quiet performance for students, writers, and nomadic engineers.',
    price: 74999,
    discountPrice: 64999,
    rating: 4.7,
    reviewsCount: 168,
    stockQuantity: 15,
    inStock: true,
    isBestSeller: true,
    releaseDate: '2026-03-05',
    thumbnailGradient: 'from-sky-950 to-slate-900',
    images: [
      'https://images.unsplash.com/photo-1541807084-5c52b6b3adef?auto=format&fit=crop&w=800&q=80',
    ],
    variants: [
      { id: 'var-laptop-2-8gb', name: '16GB RAM + 512GB SSD (Starlight)', type: 'storage', priceModifier: 0, stockQuantity: 10 },
      { id: 'var-laptop-2-16gb', name: '24GB RAM + 1TB SSD (Midnight)', type: 'storage', priceModifier: 15000, stockQuantity: 5 },
    ],
    specifications: {
      'Screen': '13.6-inch Liquid Retina Display (2560 x 1664)',
      'Processor': 'M3 Octa-Core Processor',
      'Battery': 'Up to 18 hours wireless web browsing',
      'Audio': 'Four-speaker sound system with Spatial Audio',
      'Weight': '1.24 kg'
    }
  },
  {
    id: 'prod-laptop-3',
    name: 'TitanEdge Gaming 16 RTX 4080',
    category: 'Laptops',
    brand: 'Titan',
    description: 'Uncompromising esports performance machine loaded with Intel Core i9-14900HX, RTX 4080 175W TGP GPU, vapor chamber cooling, and 240Hz QHD+ panel.',
    price: 119999,
    discountPrice: 99999,
    rating: 4.8,
    reviewsCount: 94,
    stockQuantity: 8,
    inStock: true,
    releaseDate: '2026-02-18',
    thumbnailGradient: 'from-red-950 to-slate-950',
    images: [
      'https://images.unsplash.com/photo-1603302576837-37561b2e2302?auto=format&fit=crop&w=800&q=80',
    ],
    variants: [
      { id: 'var-laptop-3-1tb', name: '32GB DDR5 + 1TB PCIe Gen4 SSD', type: 'storage', priceModifier: 0, stockQuantity: 5 },
      { id: 'var-laptop-3-2tb', name: '64GB DDR5 + 2TB PCIe Gen4 SSD', type: 'storage', priceModifier: 18000, stockQuantity: 3 },
    ],
    specifications: {
      'Display': '16.0" QHD+ (2560x1600) 240Hz, 100% DCI-P3, G-SYNC',
      'Graphics': 'NVIDIA GeForce RTX 4080 Laptop GPU (12GB GDDR6)',
      'Keyboard': 'Per-key RGB mechanical switches with 1.5mm travel',
      'Cooling': 'Dual liquid metal fans + 7 copper heat pipes',
      'Weight': '2.50 kg'
    }
  },
  {
    id: 'prod-laptop-4',
    name: 'SwiftBook Go 15 Slim',
    category: 'Laptops',
    brand: 'Apex',
    description: 'Reliable everyday companion equipped with 13th Gen Intel Core i5, anti-glare IPS display, backlit keyboard, and rapid Type-C fast charging.',
    price: 42999,
    discountPrice: 34999,
    rating: 4.4,
    reviewsCount: 112,
    stockQuantity: 20,
    inStock: true,
    releaseDate: '2026-04-15',
    thumbnailGradient: 'from-slate-800 to-slate-900',
    images: [
      'https://images.unsplash.com/photo-1496181133206-80ce9b88a853?auto=format&fit=crop&w=800&q=80',
    ],
    variants: [
      { id: 'var-laptop-4-silver', name: 'Pure Silver (16GB RAM + 512GB SSD)', type: 'color', priceModifier: 0, stockQuantity: 20 },
    ],
    specifications: {
      'Screen': '15.6-inch Full HD IPS (1920 x 1080) ComfyView',
      'Processor': 'Intel Core i5-1335U 10-Core up to 4.60 GHz',
      'Memory': '16 GB LPDDR5 Dual-Channel',
      'Storage': '512 GB NVMe M.2 SSD',
      'Weight': '1.62 kg'
    }
  },

  // --- Headphones & Audio ---
  {
    id: 'prod-headphone-1',
    name: 'AeroPulse ANC Pro Wireless',
    category: 'Headphones',
    brand: 'Pulse',
    description: 'Industry-leading Active Noise Cancellation with dual spatial audio processors, custom 40mm biocellulose drivers, and 45-hour ultra endurance battery.',
    price: 22999,
    discountPrice: 18999,
    rating: 4.9,
    reviewsCount: 410,
    stockQuantity: 12,
    inStock: true,
    isFeatured: true,
    isBestSeller: true,
    releaseDate: '2026-01-20',
    thumbnailGradient: 'from-zinc-900 to-indigo-950',
    images: [
      'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?auto=format&fit=crop&w=800&q=80',
    ],
    variants: [
      { id: 'var-hp-1-silver', name: 'Platinum Silver', type: 'color', priceModifier: 0, stockQuantity: 12 },
      // Intentional Out-Of-Stock Variant for BUG-06
      { id: 'var-hp-1-blk', name: 'Matte Black - Special Edition (Out of Stock)', type: 'color', priceModifier: 0, stockQuantity: 0 },
    ],
    specifications: {
      'Noise Cancelling': 'Adaptive Hybrid ANC with Transparency Mode',
      'Driver': '40mm High-Resolution Carbon Composite',
      'Battery Life': '45 hours with ANC ON (60 hrs ANC OFF)',
      'Connectivity': 'Bluetooth 5.4, Multipoint 3-Device Pairing, LDAC',
      'Weight': '250 grams'
    }
  },
  {
    id: 'prod-headphone-2',
    name: 'BassDrop Studio Buds Pro',
    category: 'Headphones',
    brand: 'Apex',
    description: 'True wireless in-ear earbuds with custom dynamic bass boost, IPX5 water resistance, wireless charging case, and crystal-clear 6-mic beamforming calls.',
    price: 4999,
    discountPrice: 3499,
    rating: 4.3,
    reviewsCount: 285,
    stockQuantity: 40,
    inStock: true,
    releaseDate: '2026-05-11',
    thumbnailGradient: 'from-amber-950 to-slate-900',
    images: [
      'https://images.unsplash.com/photo-1590658268037-6bf12165a8df?auto=format&fit=crop&w=800&q=80',
    ],
    variants: [
      { id: 'var-hp-2-white', name: 'Pearl White', type: 'color', priceModifier: 0, stockQuantity: 25 },
      { id: 'var-hp-2-black', name: 'Graphite Black', type: 'color', priceModifier: 0, stockQuantity: 15 },
    ],
    specifications: {
      'Water Resistance': 'IPX5 Sweat & Water Resistant',
      'Playtime': '8 hrs single charge, 32 hrs total with case',
      'Charging': 'USB-C + Qi Wireless Charging Case'
    }
  },
  {
    id: 'prod-headphone-3',
    name: 'SonicStage Soundbar 3.1 Dolby Atmos',
    category: 'Headphones',
    brand: 'Titan',
    description: 'Immersive home entertainment audio with wireless 6.5-inch subwoofer, dedicated center channel for crisp dialogue, and HDMI eARC passthrough.',
    price: 15999,
    discountPrice: 12999,
    rating: 4.6,
    reviewsCount: 77,
    stockQuantity: 9,
    inStock: true,
    releaseDate: '2026-02-14',
    thumbnailGradient: 'from-slate-900 to-blue-950',
    images: [
      'https://images.unsplash.com/photo-1545454675-3531b543be5d?auto=format&fit=crop&w=800&q=80',
    ],
    variants: [
      { id: 'var-hp-3-std', name: 'Matte Charcoal Grey', type: 'color', priceModifier: 0, stockQuantity: 9 },
    ],
    specifications: {
      'Total Output': '380W RMS Max Audio Power',
      'Channels': '3.1 Channel Dolby Atmos & DTS Virtual:X',
      'Inputs': 'HDMI eARC, Optical, USB, Bluetooth 5.3'
    }
  },
  {
    id: 'prod-headphone-4',
    name: 'StreamMic Podcaster USB Condenser',
    category: 'Headphones',
    brand: 'Nova',
    description: 'Studio-grade 24-bit/96kHz cardioid USB condenser microphone with zero-latency 3.5mm monitor port and tap-to-mute capacitive sensor.',
    price: 6499,
    discountPrice: 4999,
    rating: 4.7,
    reviewsCount: 142,
    stockQuantity: 18,
    inStock: true,
    releaseDate: '2026-03-29',
    thumbnailGradient: 'from-purple-950 to-zinc-900',
    images: [
      'https://images.unsplash.com/photo-1590658268037-6bf12165a8df?auto=format&fit=crop&w=800&q=80',
    ],
    variants: [
      { id: 'var-hp-4-std', name: 'Gunmetal Desktop Edition', type: 'color', priceModifier: 0, stockQuantity: 18 },
    ],
    specifications: {
      'Capsule': '14mm Electret Condenser',
      'Sample Rate': '96kHz / 24-bit',
      'Pattern': 'Cardioid Unidirectional'
    }
  },

  // --- Smartwatches ---
  {
    id: 'prod-watch-1',
    name: 'ChronoSync Ultra 2 Titanium GPS',
    category: 'Smartwatches',
    brand: 'Apex',
    description: 'Rugged titanium adventure smartwatch with precision dual-frequency GPS, 3000 nits sapphire crystal screen, ECG telemetry, and 100m dive rating.',
    price: 36999,
    discountPrice: 32999,
    rating: 4.9,
    reviewsCount: 189,
    stockQuantity: 14,
    inStock: true,
    isFeatured: true,
    releaseDate: '2026-01-08',
    thumbnailGradient: 'from-amber-950 to-neutral-900',
    images: [
      'https://images.unsplash.com/photo-1523275335684-37898b6baf30?auto=format&fit=crop&w=800&q=80',
    ],
    variants: [
      { id: 'var-w-1-orange', name: '49mm Titanium with Trail Loop (Orange)', type: 'color', priceModifier: 0, stockQuantity: 8 },
      { id: 'var-w-1-ocean', name: '49mm Titanium with Ocean Band (Navy)', type: 'color', priceModifier: 1500, stockQuantity: 6 },
    ],
    specifications: {
      'Case': '49mm Aerospace Titanium with Sapphire Front',
      'Battery': 'Up to 72 hours in Low Power mode',
      'Sensors': 'Dual-Frequency GPS, Blood Oxygen, ECG, Depth Gauge',
      'Water Rating': 'WR100 / EN13319 Scuba Dive to 40m'
    }
  },
  {
    id: 'prod-watch-2',
    name: 'PulseFit Active Band 7',
    category: 'Smartwatches',
    brand: 'Pulse',
    description: 'Featherlight smart fitness tracker with 1.62-inch curved AMOLED display, continuous heart rate and SpO2 tracking, and 120 sports tracking modes.',
    price: 3299,
    discountPrice: 2499,
    rating: 4.4,
    reviewsCount: 520,
    stockQuantity: 50,
    inStock: true,
    isBestSeller: true,
    releaseDate: '2026-06-18',
    thumbnailGradient: 'from-teal-950 to-slate-900',
    images: [
      'https://images.unsplash.com/photo-1579586337278-3befd40fd17a?auto=format&fit=crop&w=800&q=80',
    ],
    variants: [
      { id: 'var-w-2-blk', name: 'Midnight Black Silicone', type: 'color', priceModifier: 0, stockQuantity: 30 },
      { id: 'var-w-2-coral', name: 'Neon Coral Sport', type: 'color', priceModifier: 0, stockQuantity: 20 },
    ],
    specifications: {
      'Screen': '1.62" AMOLED Always-On Display, 500 nits',
      'Battery': 'Up to 16 days typical usage',
      'Resistance': '5 ATM Water Resistant (50 meters)'
    }
  },
  {
    id: 'prod-watch-3',
    name: 'Horizon Classic Steel Smartwatch',
    category: 'Smartwatches',
    brand: 'Titan',
    description: 'Timeless luxury craftsmanship with surgical-grade 316L stainless steel case, rotatable mechanical bezel, and smart calendar integration.',
    price: 17999,
    discountPrice: 14999,
    rating: 4.6,
    reviewsCount: 96,
    stockQuantity: 11,
    inStock: true,
    releaseDate: '2026-03-12',
    thumbnailGradient: 'from-slate-800 to-stone-900',
    images: [
      'https://images.unsplash.com/photo-1508685096489-7aacd43bd3b1?auto=format&fit=crop&w=800&q=80',
    ],
    variants: [
      { id: 'var-w-3-silver', name: '46mm Stainless Steel / Silver Link', type: 'color', priceModifier: 0, stockQuantity: 6 },
      { id: 'var-w-3-leather', name: '46mm Black Steel / Brown Italian Leather', type: 'color', priceModifier: 1000, stockQuantity: 5 },
    ],
    specifications: {
      'Bezel': 'Rotating Mechanical Navigation Bezel',
      'Compatibility': 'Android and iOS with NFC Pay',
      'Charging': 'Magnetic Wireless Fast Puck'
    }
  },
  {
    id: 'prod-watch-4',
    name: 'AeroGrip Sport GPS Pace',
    category: 'Smartwatches',
    brand: 'Nova',
    description: 'Marathon runner watch designed with hyper-light composite polymer case, transflective memory-in-pixel sunlight display, and VO2 max estimation.',
    price: 11999,
    discountPrice: 9999,
    rating: 4.5,
    reviewsCount: 130,
    stockQuantity: 16,
    inStock: true,
    releaseDate: '2026-04-02',
    thumbnailGradient: 'from-lime-950 to-slate-900',
    images: [
      'https://images.unsplash.com/photo-1510017803434-a899398421b3?auto=format&fit=crop&w=800&q=80',
    ],
    variants: [
      { id: 'var-w-4-volt', name: 'Volt Yellow Sport Band', type: 'color', priceModifier: 0, stockQuantity: 8 },
      { id: 'var-w-4-stealth', name: 'Stealth Grey Nylon', type: 'color', priceModifier: 0, stockQuantity: 8 },
    ],
    specifications: {
      'Weight': '38 grams ultra-lightweight',
      'GPS Endurance': '30 continuous hours full GPS tracking',
      'Metrics': 'Cadence, Vertical Oscillation, Ground Contact Time'
    }
  },

  // --- Gaming Products ---
  {
    id: 'prod-gaming-1',
    name: 'ApexTrigger Elite Wireless Gamepad',
    category: 'Gaming',
    brand: 'Apex',
    description: 'Competition esports controller with electromagnetic Hall Effect joysticks, hair-trigger stop locks, remappable rear paddles, and 1000Hz polling rate.',
    price: 5499,
    discountPrice: 4299,
    rating: 4.8,
    reviewsCount: 312,
    stockQuantity: 24,
    inStock: true,
    isBestSeller: true,
    releaseDate: '2026-02-10',
    thumbnailGradient: 'from-violet-950 to-slate-950',
    images: [
      'https://images.unsplash.com/photo-1600080972464-8e5f35f63d08?auto=format&fit=crop&w=800&q=80',
    ],
    variants: [
      { id: 'var-game-1-white', name: 'Polar White / Rubberized Grip', type: 'color', priceModifier: 0, stockQuantity: 14 },
      { id: 'var-game-1-camo', name: 'Cyberpunk Purple Special Edition', type: 'color', priceModifier: 500, stockQuantity: 10 },
    ],
    specifications: {
      'Sticks': 'Anti-Drift Hall Effect Magnetic Sensors',
      'Latency': '< 1ms ultra-low 2.4GHz Wireless / Bluetooth / Type-C',
      'Compatibility': 'PC, PlayStation 5, Switch, Android, iOS'
    }
  },
  {
    id: 'prod-gaming-2',
    name: 'VortexRGB Hot-Swap Mechanical Keyboard',
    category: 'Gaming',
    brand: 'Titan',
    description: '75% compact mechanical keyboard with gasket mount structure, pre-lubed linear switches, sound-dampening foam, and south-facing per-key RGB backlighting.',
    price: 7499,
    discountPrice: 5999,
    rating: 4.7,
    reviewsCount: 175,
    stockQuantity: 15,
    inStock: true,
    releaseDate: '2026-03-14',
    thumbnailGradient: 'from-rose-950 to-slate-900',
    images: [
      'https://images.unsplash.com/photo-1587829741301-dc798b83add3?auto=format&fit=crop&w=800&q=80',
    ],
    variants: [
      { id: 'var-game-2-red', name: 'Linear Red Switches (Smooth & Silent)', type: 'color', priceModifier: 0, stockQuantity: 9 },
      { id: 'var-game-2-blue', name: 'Tactile Blue Switches (Clicky Feedback)', type: 'color', priceModifier: 0, stockQuantity: 6 },
    ],
    specifications: {
      'Layout': '75% with 82 Keys + CNC Aluminum Rotary Volume Knob',
      'Keycaps': 'Double-shot PBT Cherry Profile',
      'Connectivity': 'Tri-mode: Type-C Wired, Bluetooth 5.1, 2.4GHz'
    }
  },
  {
    id: 'prod-gaming-3',
    name: 'HyperGlide Pro Wireless Gaming Mouse',
    category: 'Gaming',
    brand: 'Nova',
    description: 'Ultra-lightweight 49-gram symmetrical esports gaming mouse featuring 32,000 DPI optical sensor and 4000Hz hyper-polling wireless dongle.',
    price: 4999,
    discountPrice: 3999,
    rating: 4.7,
    reviewsCount: 204,
    stockQuantity: 19,
    inStock: true,
    releaseDate: '2026-04-10',
    thumbnailGradient: 'from-indigo-950 to-slate-900',
    images: [
      'https://images.unsplash.com/photo-1615663245857-ac93bb7c39e7?auto=format&fit=crop&w=800&q=80',
    ],
    variants: [
      { id: 'var-game-3-black', name: 'Matte Stealth Black', type: 'color', priceModifier: 0, stockQuantity: 11 },
      { id: 'var-game-3-white', name: 'Chalk White', type: 'color', priceModifier: 0, stockQuantity: 8 },
    ],
    specifications: {
      'Weight': '49 grams solid shell without honeycomb holes',
      'Sensor': 'PAW3395 Optical (32,000 DPI, 650 IPS)',
      'Battery': 'Up to 90 continuous hours at 1000Hz polling'
    }
  },
  {
    id: 'prod-gaming-4',
    name: 'OmniVision Curved 27" 165Hz Monitor',
    category: 'Gaming',
    brand: 'Apex',
    description: '1500R immersive curvature gaming display with Fast IPS panel, 1ms GtG response time, AMD FreeSync Premium Pro, and height-adjustable stand.',
    price: 25999,
    discountPrice: 21999,
    rating: 4.6,
    reviewsCount: 88,
    stockQuantity: 0, // Intentional Out-of-Stock product
    inStock: false,
    releaseDate: '2026-05-02',
    thumbnailGradient: 'from-cyan-950 to-slate-950',
    images: [
      'https://images.unsplash.com/photo-1527443224154-c4a3942d3acf?auto=format&fit=crop&w=800&q=80',
    ],
    variants: [
      { id: 'var-game-4-std', name: '27-inch 165Hz QHD Display', type: 'size', priceModifier: 0, stockQuantity: 0 },
    ],
    specifications: {
      'Panel': '27-inch 2560 x 1440 Fast IPS Curvature 1500R',
      'Refresh Rate': '165Hz with 1ms GtG Response',
      'Color Gamut': '98% DCI-P3, HDR400 Certified'
    }
  },

  // --- Accessories ---
  {
    id: 'prod-acc-1',
    name: 'MagPower 10,000mAh Magnetic Powerbank',
    category: 'Accessories',
    brand: 'Apex',
    description: 'Slimline magnetic wireless powerbank with 15W Qi2 fast wireless charging, kickstand fold-out leg, and 20W PD Type-C bidirectional port.',
    price: 2499,
    discountPrice: 1999,
    rating: 4.5,
    reviewsCount: 430,
    stockQuantity: 35,
    inStock: true,
    isBestSeller: true,
    releaseDate: '2026-02-28',
    thumbnailGradient: 'from-slate-800 to-indigo-950',
    images: [
      'https://images.unsplash.com/photo-1609592424109-dd9892f1b177?auto=format&fit=crop&w=800&q=80',
    ],
    variants: [
      { id: 'var-acc-1-black', name: 'Space Grey Aluminum', type: 'color', priceModifier: 0, stockQuantity: 20 },
      { id: 'var-acc-1-white', name: 'Frost White Matte', type: 'color', priceModifier: 0, stockQuantity: 15 },
    ],
    specifications: {
      'Capacity': '10,000 mAh / 38.5Wh Airline Safe',
      'Wireless Output': '15W Fast Magnetic Wireless',
      'Wired Output': 'USB-C Power Delivery 20W Max'
    }
  },
  {
    id: 'prod-acc-2',
    name: 'HyperCharge 100W GaN 4-Port Fast Adapter',
    category: 'Accessories',
    brand: 'Pulse',
    description: 'Compact Gallium Nitride (GaN) fast charger with 3x USB-C ports and 1x USB-A port capable of simultaneously charging two laptops and two phones.',
    price: 3499,
    discountPrice: 2799,
    rating: 4.7,
    reviewsCount: 290,
    stockQuantity: 28,
    inStock: true,
    releaseDate: '2026-03-01',
    thumbnailGradient: 'from-amber-950 to-neutral-900',
    images: [
      'https://images.unsplash.com/photo-1583863788434-e58a36330cf0?auto=format&fit=crop&w=800&q=80',
    ],
    variants: [
      { id: 'var-acc-2-std', name: 'Midnight Matte Black 100W', type: 'color', priceModifier: 0, stockQuantity: 28 },
    ],
    specifications: {
      'Total Output': '100W Maximum Power Delivery 3.0 / PPS',
      'Ports': '3x USB-C + 1x USB-A Fast Charging',
      'Technology': 'GaN III Efficient Semiconductor Cooling'
    }
  },
  {
    id: 'prod-acc-3',
    name: 'FlexiStand Ergonomic Aluminum Laptop Riser',
    category: 'Accessories',
    brand: 'Nova',
    description: 'Solid CNC machined aerospace aluminum riser with 360-degree rotating base, dual-axis angle adjustment, and anti-slip silicone cushions.',
    price: 1999,
    discountPrice: 1499,
    rating: 4.6,
    reviewsCount: 165,
    stockQuantity: 22,
    inStock: true,
    releaseDate: '2026-01-25',
    thumbnailGradient: 'from-slate-800 to-slate-900',
    images: [
      'https://images.unsplash.com/photo-1527864550417-7fd91fc51a46?auto=format&fit=crop&w=800&q=80',
    ],
    variants: [
      { id: 'var-acc-3-silver', name: 'Anodized Silver Finish', type: 'color', priceModifier: 0, stockQuantity: 12 },
      { id: 'var-acc-3-grey', name: 'Space Grey Finish', type: 'color', priceModifier: 0, stockQuantity: 10 },
    ],
    specifications: {
      'Material': 'Solid 3.5mm CNC Anodized Aluminum Alloy',
      'Compatibility': 'Laptops and tablets 10 inches to 17.3 inches',
      'Weight Capacity': 'Holds up to 10 kg securely'
    }
  },
  {
    id: 'prod-acc-4',
    name: 'Apex Braided 240W USB-C to USB-C Cable 2m',
    category: 'Accessories',
    brand: 'Apex',
    description: 'Heavy-duty Kevlar-reinforced double braided nylon cable with E-Marker smart chip delivering full 240W Power Delivery and 480Mbps data transfer.',
    price: 1199,
    discountPrice: 799,
    rating: 4.4,
    reviewsCount: 610,
    stockQuantity: 80,
    inStock: true,
    isBestSeller: true,
    releaseDate: '2026-02-05',
    thumbnailGradient: 'from-zinc-800 to-zinc-950',
    images: [
      'https://images.unsplash.com/photo-1544816155-12df9643f363?auto=format&fit=crop&w=800&q=80',
    ],
    variants: [
      { id: 'var-acc-4-2m', name: '2 Meter Braided Black', type: 'size', priceModifier: 0, stockQuantity: 50 },
      { id: 'var-acc-4-3m', name: '3 Meter Braided Black', type: 'size', priceModifier: 200, stockQuantity: 30 },
    ],
    specifications: {
      'Power Rating': '240W (48V/5A) USB-IF Certified EPR',
      'Durability': 'Tested for 40,000+ 90-degree bends',
      'Length': '2 meters / 6.6 feet'
    }
  }
];
