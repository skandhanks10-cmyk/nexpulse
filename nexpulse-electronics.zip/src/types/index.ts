export type ProductCategory =
  | 'Smartphones'
  | 'Laptops'
  | 'Headphones'
  | 'Smartwatches'
  | 'Gaming'
  | 'Accessories';

export interface ProductVariant {
  id: string;
  name: string;
  type: 'color' | 'storage' | 'ram' | 'size';
  priceModifier: number;
  stockQuantity: number;
  attributes?: Record<string, string>;
}

export interface Product {
  id: string;
  name: string;
  category: ProductCategory;
  description: string;
  price: number; // Original MRP
  discountPrice: number; // Current selling price
  brand: string;
  rating: number;
  reviewsCount: number;
  stockQuantity: number;
  inStock: boolean;
  variants: ProductVariant[];
  images: string[];
  thumbnailGradient: string;
  specifications: Record<string, string>;
  isFeatured?: boolean;
  isBestSeller?: boolean;
  releaseDate?: string;
}

export interface CartItem {
  cartItemId: string;
  productId: string;
  name: string;
  brand: string;
  category: ProductCategory;
  unitPrice: number;
  originalPrice: number;
  quantity: number;
  selectedVariant?: ProductVariant;
  subtotal: number;
  image: string;
}

export interface CartSummary {
  subtotal: number;
  discount: number;
  couponCode?: string;
  shipping: number;
  tax: number;
  grandTotal: number;
  itemCount: number;
}

export interface Coupon {
  code: string;
  description: string;
  type: 'percentage' | 'fixed';
  value: number;
  minOrderValue: number;
  maxDiscount?: number;
  expiryDate: string; // ISO date string
  isActive: boolean;
}

export type CheckoutStep = 1 | 2 | 3 | 4;

export interface CustomerInfo {
  fullName: string;
  email: string;
  phone: string;
}

export interface ShippingAddress {
  street: string;
  city: string;
  state: string;
  pincode: string;
}

export type PaymentMethod = 'card' | 'upi' | 'cod';

export interface PaymentDetails {
  method: PaymentMethod;
  cardDetails?: {
    cardNumber: string;
    expiry: string;
    cvv: string;
    cardHolder: string;
  };
  upiId?: string;
}

export interface Order {
  orderId: string;
  createdAt: string;
  items: CartItem[];
  customerInfo: CustomerInfo;
  shippingAddress: ShippingAddress;
  paymentMethod: PaymentMethod;
  summary: CartSummary;
  estimatedDelivery: string;
}
