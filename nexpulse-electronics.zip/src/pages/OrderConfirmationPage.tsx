import React from 'react';
import {
  CheckCircle2,
  Package,
  Calendar,
  CreditCard,
  MapPin,
  ArrowRight,
  ShoppingBag,
} from 'lucide-react';
import { orderService } from '../services/orderService';

interface OrderConfirmationPageProps {
  orderId?: string;
  onContinueShopping: () => void;
}

export const OrderConfirmationPage: React.FC<OrderConfirmationPageProps> = ({
  orderId,
  onContinueShopping,
}) => {
  const order = orderId
    ? orderService.getOrderById(orderId) || orderService.getLatestOrder()
    : orderService.getLatestOrder();

  if (!order) {
    return (
      <div className="max-w-xl mx-auto py-16 text-center">
        <h2 className="text-xl font-bold text-slate-900">No active order found</h2>
        <button
          onClick={onContinueShopping}
          className="mt-4 px-4 py-2 bg-slate-900 text-white rounded-lg text-xs font-semibold"
        >
          Return to Store
        </button>
      </div>
    );
  }

  const paymentLabel =
    order.paymentMethod === 'card'
      ? 'Credit/Debit Card'
      : order.paymentMethod === 'upi'
      ? 'UPI Instant Transfer'
      : 'Cash on Delivery (COD)';

  return (
    <div className="max-w-3xl mx-auto px-4 sm:px-6 py-12">
      {/* Success Badge & Header */}
      <div className="text-center mb-8">
        <div className="w-16 h-16 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mx-auto mb-4 ring-8 ring-emerald-50">
          <CheckCircle2 className="w-10 h-10" />
        </div>
        <h1 className="text-3xl font-extrabold text-slate-900 tracking-tight">
          Order Confirmed!
        </h1>
        <p className="text-sm text-slate-500 mt-1">
          Thank you for shopping with NexPulse. We have initiated dispatch preparation.
        </p>
      </div>

      {/* Main Order Card */}
      <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-xs divide-y divide-slate-100">
        {/* Order Meta Bar */}
        <div className="p-6 bg-slate-50/80 grid grid-cols-2 sm:grid-cols-4 gap-4 text-xs">
          <div>
            <span className="text-slate-400 font-semibold uppercase tracking-wider block">
              Order ID
            </span>
            <span className="font-mono font-bold text-slate-900 mt-1 block">
              {order.orderId}
            </span>
          </div>

          <div>
            <span className="text-slate-400 font-semibold uppercase tracking-wider block">
              Estimated Delivery
            </span>
            <span className="font-semibold text-indigo-700 mt-1 block">
              {order.estimatedDelivery}
            </span>
          </div>

          <div>
            <span className="text-slate-400 font-semibold uppercase tracking-wider block">
              Payment Method
            </span>
            <span className="font-semibold text-slate-900 mt-1 block">
              {paymentLabel}
            </span>
          </div>

          <div>
            <span className="text-slate-400 font-semibold uppercase tracking-wider block">
              Total Paid
            </span>
            <span className="font-mono font-extrabold text-slate-900 mt-1 block text-sm">
              ₹{order.summary.grandTotal.toLocaleString('en-IN')}
            </span>
          </div>
        </div>

        {/* Ordered Products List */}
        <div className="p-6">
          <h2 className="text-xs font-bold uppercase tracking-wider text-slate-900 mb-4 flex items-center gap-2">
            <Package className="w-4 h-4 text-indigo-600" />
            <span>Ordered Items ({order.items.length})</span>
          </h2>

          <div className="divide-y divide-slate-100">
            {order.items.map((item) => (
              <div
                key={item.cartItemId}
                className="py-3 flex items-center justify-between text-xs"
              >
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 bg-slate-100 rounded-lg overflow-hidden shrink-0 border border-slate-200">
                    {item.image ? (
                      <img
                        src={item.image}
                        alt={item.name}
                        className="w-full h-full object-cover"
                      />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center text-slate-400">
                        <ShoppingBag className="w-5 h-5" />
                      </div>
                    )}
                  </div>
                  <div>
                    <h3 className="font-bold text-slate-900">{item.name}</h3>
                    <div className="text-slate-500 mt-0.5">
                      {item.selectedVariant?.name || 'Standard'} · Qty: {item.quantity}
                    </div>
                  </div>
                </div>

                <div className="text-right">
                  <span className="font-mono font-bold text-slate-900 tabular-nums">
                    ₹{item.subtotal.toLocaleString('en-IN')}
                  </span>
                  <span className="text-[11px] text-slate-400 block">
                    (₹{item.unitPrice.toLocaleString('en-IN')} each)
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Shipping Destination */}
        <div className="p-6 bg-slate-50/50">
          <h2 className="text-xs font-bold uppercase tracking-wider text-slate-900 mb-3 flex items-center gap-2">
            <MapPin className="w-4 h-4 text-indigo-600" />
            <span>Shipping Destination</span>
          </h2>
          <div className="text-xs text-slate-700 leading-relaxed">
            <span className="font-semibold block text-slate-900">
              {order.customerInfo.fullName}
            </span>
            <span>{order.shippingAddress.street}</span>,{' '}
            <span>{order.shippingAddress.city}</span>,{' '}
            <span>{order.shippingAddress.state}</span>{' '}
            {order.shippingAddress.pincode && <span>- {order.shippingAddress.pincode}</span>}
            <div className="text-slate-500 mt-1">
              Contact: {order.customerInfo.phone} · {order.customerInfo.email}
            </div>
          </div>
        </div>

        {/* Summary Breakdown */}
        <div className="p-6 text-xs space-y-2">
          <div className="flex justify-between text-slate-600">
            <span>Subtotal</span>
            <span className="font-mono tabular-nums">
              ₹{order.summary.subtotal.toLocaleString('en-IN')}
            </span>
          </div>

          {order.summary.discount > 0 && (
            <div className="flex justify-between text-emerald-600 font-semibold">
              <span>Coupon Discount ({order.summary.couponCode})</span>
              <span className="font-mono tabular-nums">
                -₹{order.summary.discount.toLocaleString('en-IN')}
              </span>
            </div>
          )}

          <div className="flex justify-between text-slate-600">
            <span>Shipping</span>
            <span className="font-mono tabular-nums">
              {order.summary.shipping === 0 ? 'FREE' : `₹${order.summary.shipping}`}
            </span>
          </div>

          <div className="flex justify-between text-slate-600">
            <span>Tax (GST)</span>
            <span className="font-mono tabular-nums">
              ₹{order.summary.tax.toLocaleString('en-IN')}
            </span>
          </div>

          <div className="pt-2 border-t border-slate-200 flex justify-between font-bold text-slate-900 text-sm">
            <span>Final Amount Charged</span>
            <span className="font-mono tabular-nums">
              ₹{order.summary.grandTotal.toLocaleString('en-IN')}
            </span>
          </div>
        </div>
      </div>

      {/* Continue Shopping CTA */}
      <div className="mt-8 text-center">
        <button
          onClick={onContinueShopping}
          className="px-6 py-3.5 bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold uppercase tracking-wider rounded-xl transition-colors inline-flex items-center gap-2 shadow-sm"
        >
          <span>Continue Shopping</span>
          <ArrowRight className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
};
