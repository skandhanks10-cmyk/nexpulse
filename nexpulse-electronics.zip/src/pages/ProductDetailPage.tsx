import React, { useState, useMemo } from 'react';
import {
  Star,
  ShoppingBag,
  ArrowLeft,
  Truck,
  ShieldCheck,
  RotateCcw,
  Check,
  AlertCircle,
  Zap,
} from 'lucide-react';
import { Product, ProductVariant } from '../types';
import { ProductVisual } from '../components/ProductVisual';
import { useCart } from '../context/CartContext';

interface ProductDetailPageProps {
  product: Product;
  onBack: () => void;
  onNavigateToCart: () => void;
  onNavigateToCheckout: () => void;
}

export const ProductDetailPage: React.FC<ProductDetailPageProps> = ({
  product,
  onBack,
  onNavigateToCart,
  onNavigateToCheckout,
}) => {
  const { addItem } = useCart();

  // Active selected variant
  const [selectedVariant, setSelectedVariant] = useState<ProductVariant | undefined>(
    product.variants[0]
  );
  const [quantity, setQuantity] = useState(1);
  const [activeImageIndex, setActiveImageIndex] = useState(0);
  const [addedToast, setAddedToast] = useState(false);

  // Dynamic price calculation
  const currentPrice = useMemo(() => {
    return product.discountPrice + (selectedVariant?.priceModifier || 0);
  }, [product.discountPrice, selectedVariant]);

  const originalMrp = useMemo(() => {
    return product.price + (selectedVariant?.priceModifier || 0);
  }, [product.price, selectedVariant]);

  const discountPercent = Math.round(((originalMrp - currentPrice) / originalMrp) * 100);

  // Stock status check
  // INTENTIONAL DEFECT: BUG-06 (Out-of-Stock Bug)
  // Notice that while the UI display shows variant stock info, the button disabled check evaluates
  // `!product.inStock` rather than `(selectedVariant && selectedVariant.stockQuantity <= 0)`!
  // This allows the user to add 0-stock variants (like 'Matte Black' on AeroPulse ANC) to the cart!
  const isOutOfStock = !product.inStock; // <-- DEFECT: Should check selectedVariant?.stockQuantity === 0

  const handleAddToCart = () => {
    if (isOutOfStock) return;
    addItem(product, selectedVariant, quantity);
    setAddedToast(true);
    setTimeout(() => setAddedToast(false), 3000);
  };

  const handleBuyNow = () => {
    if (isOutOfStock) return;
    addItem(product, selectedVariant, quantity);
    onNavigateToCheckout();
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Back button */}
      <button
        onClick={onBack}
        className="inline-flex items-center gap-1.5 text-xs font-semibold text-slate-600 hover:text-slate-900 mb-6 group transition-colors"
      >
        <ArrowLeft className="w-4 h-4 group-hover:-translate-x-0.5 transition-transform" />
        <span>Back to Products</span>
      </button>

      {/* Main Contiguous Purchase Module */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-start">
        {/* Left Column: Visual Gallery */}
        <div className="lg:col-span-7 space-y-4">
          <div className="bg-white p-4 rounded-2xl border border-slate-200">
            <ProductVisual
              imageSrc={product.images[activeImageIndex] || product.images[0]}
              name={product.name}
              category={product.category}
              gradient={product.thumbnailGradient}
              aspectRatio="square"
              className="rounded-xl shadow-inner"
            />
          </div>

          {/* Thumbnail Gallery Strip */}
          {product.images.length > 1 && (
            <div className="flex items-center gap-3">
              {product.images.map((img, idx) => (
                <button
                  key={idx}
                  onClick={() => setActiveImageIndex(idx)}
                  className={`w-20 h-20 rounded-lg overflow-hidden border-2 transition-all ${
                    activeImageIndex === idx
                      ? 'border-indigo-600 ring-2 ring-indigo-100'
                      : 'border-slate-200 hover:border-slate-300'
                  }`}
                >
                  <img
                    src={img}
                    alt={`${product.name} angle ${idx + 1}`}
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover"
                  />
                </button>
              ))}
            </div>
          )}

          {/* Specifications Table */}
          <div className="bg-white rounded-2xl border border-slate-200 p-6 mt-8">
            <h3 className="text-base font-bold text-slate-900 mb-4 pb-2 border-b border-slate-100">
              Technical Specifications
            </h3>
            <div className="divide-y divide-slate-100">
              {Object.entries(product.specifications).map(([key, value]) => (
                <div key={key} className="py-2.5 grid grid-cols-1 sm:grid-cols-3 gap-2 text-xs">
                  <span className="font-semibold text-slate-500 uppercase tracking-wider">
                    {key}
                  </span>
                  <span className="sm:col-span-2 text-slate-800 font-medium">{value}</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Right Column: Sticky Purchase Module */}
        <div className="lg:col-span-5 sticky top-24 space-y-6">
          <div className="bg-white rounded-2xl border border-slate-200 p-6 sm:p-8 shadow-xs">
            {/* Brand & Category */}
            <div className="flex items-center justify-between text-xs text-slate-400 uppercase tracking-wider font-semibold mb-2">
              <span>{product.brand}</span>
              <span>{product.category}</span>
            </div>

            {/* Title */}
            <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight leading-snug">
              {product.name}
            </h1>

            {/* Rating & Review Count */}
            <div className="flex items-center gap-2 mt-3 text-xs">
              <div className="flex items-center gap-1 text-amber-500">
                <Star className="w-4 h-4 fill-current" />
                <span className="font-bold text-slate-900">{product.rating}</span>
              </div>
              <span className="text-slate-300">·</span>
              <span className="text-slate-500 font-medium">
                {product.reviewsCount} Customer Reviews
              </span>
              <span className="text-slate-300">·</span>
              <span className="text-emerald-700 font-medium flex items-center gap-1">
                <Check className="w-3.5 h-3.5" />
                Verified Buyer Rating
              </span>
            </div>

            {/* Pricing Area */}
            <div className="mt-6 pt-6 border-t border-slate-100">
              <div className="flex items-baseline gap-3">
                <span className="text-3xl font-extrabold text-slate-900 font-mono tabular-nums">
                  ₹{currentPrice.toLocaleString('en-IN')}
                </span>
                {originalMrp > currentPrice && (
                  <span className="text-base text-slate-400 line-through font-mono tabular-nums">
                    ₹{originalMrp.toLocaleString('en-IN')}
                  </span>
                )}
                {discountPercent > 0 && (
                  <span className="text-xs font-bold text-emerald-800 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                    {discountPercent}% OFF
                  </span>
                )}
              </div>
              <p className="text-xs text-slate-400 mt-1">Inclusive of all local taxes (GST)</p>
            </div>

            {/* Variant Selector */}
            {product.variants.length > 0 && (
              <div className="mt-6 pt-6 border-t border-slate-100">
                <label className="text-xs font-bold uppercase tracking-wider text-slate-700 block mb-3">
                  Select Option: <span className="text-indigo-600 font-semibold">{selectedVariant?.name}</span>
                </label>
                <div className="space-y-2">
                  {product.variants.map((v) => {
                    const isSelected = selectedVariant?.id === v.id;
                    const isVariantZeroStock = v.stockQuantity === 0;

                    return (
                      <button
                        key={v.id}
                        type="button"
                        onClick={() => setSelectedVariant(v)}
                        className={`w-full text-left p-3 rounded-lg border text-xs flex items-center justify-between transition-all ${
                          isSelected
                            ? 'border-indigo-600 bg-indigo-50/50 ring-1 ring-indigo-600'
                            : 'border-slate-200 hover:border-slate-300 bg-slate-50/50'
                        }`}
                      >
                        <div className="flex flex-col">
                          <span className="font-semibold text-slate-900">{v.name}</span>
                          {isVariantZeroStock ? (
                            <span className="text-[11px] text-rose-600 font-semibold mt-0.5">
                              Out of stock at warehouse
                            </span>
                          ) : (
                            <span className="text-[11px] text-slate-400 mt-0.5">
                              {v.stockQuantity} units available
                            </span>
                          )}
                        </div>

                        <div className="text-right">
                          {v.priceModifier > 0 && (
                            <span className="font-mono text-xs font-bold text-indigo-700">
                              +₹{v.priceModifier.toLocaleString('en-IN')}
                            </span>
                          )}
                        </div>
                      </button>
                    );
                  })}
                </div>
              </div>
            )}

            {/* Quantity Stepper */}
            <div className="mt-6 pt-6 border-t border-slate-100 flex items-center justify-between">
              <span className="text-xs font-bold uppercase tracking-wider text-slate-700">
                Quantity
              </span>
              <div className="flex items-center border border-slate-200 rounded-lg overflow-hidden bg-slate-50">
                <button
                  type="button"
                  onClick={() => setQuantity((q) => Math.max(1, q - 1))}
                  className="px-3 py-1.5 text-slate-600 hover:bg-slate-200 font-bold transition-colors"
                >
                  -
                </button>
                <span className="px-4 py-1.5 text-xs font-mono font-bold text-slate-900 tabular-nums">
                  {quantity}
                </span>
                <button
                  type="button"
                  onClick={() => setQuantity((q) => q + 1)}
                  className="px-3 py-1.5 text-slate-600 hover:bg-slate-200 font-bold transition-colors"
                >
                  +
                </button>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="mt-8 space-y-3">
              <button
                type="button"
                onClick={handleAddToCart}
                disabled={isOutOfStock}
                className={`w-full py-3.5 px-4 rounded-xl text-sm font-bold flex items-center justify-center gap-2 transition-all shadow-sm ${
                  isOutOfStock
                    ? 'bg-slate-200 text-slate-400 cursor-not-allowed'
                    : 'bg-slate-900 hover:bg-slate-800 text-white'
                }`}
              >
                <ShoppingBag className="w-4 h-4" />
                <span>Add to Cart</span>
              </button>

              <button
                type="button"
                onClick={handleBuyNow}
                disabled={isOutOfStock}
                className={`w-full py-3 px-4 rounded-xl text-sm font-bold flex items-center justify-center gap-2 border transition-all ${
                  isOutOfStock
                    ? 'border-slate-200 text-slate-400 cursor-not-allowed'
                    : 'border-slate-900 text-slate-900 hover:bg-slate-50'
                }`}
              >
                <Zap className="w-4 h-4 text-amber-500 fill-amber-500" />
                <span>Buy Now with 1-Click</span>
              </button>
            </div>

            {/* Notification Toast */}
            {addedToast && (
              <div className="mt-4 p-3 bg-emerald-50 border border-emerald-200 rounded-lg flex items-center justify-between text-xs text-emerald-800 animate-fadeIn">
                <span className="font-semibold">Added to shopping cart!</span>
                <button
                  onClick={onNavigateToCart}
                  className="font-bold underline underline-offset-2 hover:text-emerald-950"
                >
                  View Cart →
                </button>
              </div>
            )}

            {/* Delivery & Trust Highlights */}
            <div className="mt-6 pt-6 border-t border-slate-100 space-y-3 text-xs text-slate-600">
              <div className="flex items-center gap-3">
                <Truck className="w-4 h-4 text-indigo-600 shrink-0" />
                <span>Fast 3–5 Business Day Delivery nationwide</span>
              </div>
              <div className="flex items-center gap-3">
                <ShieldCheck className="w-4 h-4 text-indigo-600 shrink-0" />
                <span>1-Year Official Brand Warranty included</span>
              </div>
              <div className="flex items-center gap-3">
                <RotateCcw className="w-4 h-4 text-indigo-600 shrink-0" />
                <span>7-Day Replacement Guarantee if defective</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
