import React, { useState } from 'react';
import {
  ShieldCheck,
  Play,
  RotateCcw,
  CheckCircle,
  XCircle,
  AlertTriangle,
  Database,
  ExternalLink,
  ChevronDown,
  ChevronRight,
  Code2,
  ListFilter,
  Check,
} from 'lucide-react';
import { useCart } from '../context/CartContext';
import { cartService } from '../services/cartService';
import { shippingService } from '../services/shippingService';
import { couponService } from '../services/couponService';
import { filterService } from '../services/filterService';
import { searchService } from '../services/searchService';
import { checkoutService } from '../services/checkoutService';
import { productService } from '../services/productService';
import { COUPON_DATABASE } from '../data/coupons';

interface TestResult {
  id: string;
  name: string;
  category: string;
  status: 'passed' | 'failed' | 'pending';
  expected: string;
  actual: string;
  reproductionSteps: string[];
  rootCause: string;
}

interface QADashboardPageProps {
  onNavigate: (view: string, params?: any) => void;
}

export const QADashboardPage: React.FC<QADashboardPageProps> = ({ onNavigate }) => {
  const { items, summary, residualOffset, couponCode, clearCart, addItem } = useCart();
  const [isRunningAll, setIsRunningAll] = useState(false);
  const [activeTab, setActiveTab] = useState<'diagnostics' | 'inspector' | 'rules'>('diagnostics');
  const [expandedBugId, setExpandedBugId] = useState<string | null>('BUG-01');

  const [testResults, setTestResults] = useState<TestResult[]>([
    {
      id: 'BUG-01',
      name: 'Cart Item Quantity Subtotal Desync',
      category: 'Cart Service',
      status: 'pending',
      expected: 'Incrementing item quantity to 3 computes: unitPrice × 3 = total line amount',
      actual: 'Pending test execution...',
      reproductionSteps: [
        '1. Add any product to cart (e.g. BassDrop Studio Buds @ ₹3,499).',
        '2. Open Shopping Cart page.',
        '3. Click "+" stepper twice to increase quantity to 3.',
        '4. Observe the line-item subtotal displays ₹6,998 instead of ₹10,497 (calculates for qty 2).',
      ],
      rootCause:
        'cartService.ts: updateItemQuantity uses `item.unitPrice * (newQuantity - 1)` for newQuantity >= 3.',
    },
    {
      id: 'BUG-02',
      name: 'Removed Item Residual Balance Retention',
      category: 'Cart Service',
      status: 'pending',
      expected: 'Removing an item completely subtracts 100% of its price from the cart subtotal',
      actual: 'Pending test execution...',
      reproductionSteps: [
        '1. Add a high-value product to cart (e.g. ₹10,000).',
        '2. Open Cart and record the subtotal.',
        '3. Click the trash icon to remove the item.',
        '4. Inspect the subtotal: 20% of the removed item price remains in the cart subtotal balance.',
      ],
      rootCause:
        'cartService.ts: removeItem adds `removedItem.unitPrice * 0.20` to `residualOffset`, which is retained in cart calculations.',
    },
    {
      id: 'BUG-03',
      name: 'Coupon Discount Calculation Base Mismatch',
      category: 'Coupon Service',
      status: 'pending',
      expected: 'WELCOME15 coupon calculates 15% discount against the current discounted subtotal',
      actual: 'Pending test execution...',
      reproductionSteps: [
        '1. Add product with large difference between MRP and selling price (e.g. SwiftBook Go 15, MRP ₹42,999, selling ₹34,999).',
        '2. In Cart, apply coupon code "WELCOME15".',
        '3. Check discount: calculated against gross original MRP instead of selling subtotal.',
      ],
      rootCause:
        'couponService.ts: For WELCOME15, multiplies against `grossMrpTotal` rather than `subtotal`.',
    },
    {
      id: 'BUG-04',
      name: 'Search Relevance & Spec Tag Bleed',
      category: 'Search Service',
      status: 'pending',
      expected: 'Searching "laptop" ranks Laptops at the top and excludes non-laptop accessories',
      actual: 'Pending test execution...',
      reproductionSteps: [
        '1. Enter "laptop" into the search bar.',
        '2. View search results.',
        '3. Observe "FlexiStand Ergonomic Aluminum Laptop Riser" (Accessories) ranks ahead of actual Laptops.',
      ],
      rootCause:
        'searchService.ts: Broad specification text scanning with custom sort inversion prioritizes accessory matches.',
    },
    {
      id: 'BUG-05',
      name: 'Price Range Filter Pre-Discount MRP Evaluation',
      category: 'Filter Service',
      status: 'pending',
      expected: 'Price filter "Under ₹5,000" includes products whose selling price is under ₹5,000',
      actual: 'Pending test execution...',
      reproductionSteps: [
        '1. Navigate to Products Catalog.',
        '2. Select "Under ₹5,000" price filter.',
        '3. Notice "ApexTrigger Elite Wireless Gamepad" (selling at ₹4,299) is missing because its MRP is ₹5,499.',
      ],
      rootCause:
        'filterService.ts: Evaluates `product.price` (pre-discount MRP) rather than `product.discountPrice`.',
    },
    {
      id: 'BUG-06',
      name: 'Out-of-Stock Variant Add-to-Cart Bypass',
      category: 'Product Details',
      status: 'pending',
      expected: 'Selecting an out-of-stock variant disables the Add to Cart button',
      actual: 'Pending test execution...',
      reproductionSteps: [
        '1. Open "AeroPulse ANC Pro Wireless" (prod-headphone-1).',
        '2. In Variant Selector, pick "Matte Black - Special Edition (Out of Stock)".',
        '3. Observe the "Add to Cart" button remains clickable and successfully adds 0-stock inventory.',
      ],
      rootCause:
        'ProductDetailPage.tsx: `isOutOfStock` only evaluates `!product.inStock` (true for parent) instead of `selectedVariant.stockQuantity <= 0`.',
    },
    {
      id: 'BUG-07',
      name: 'Shipping Boundary Fee Calculation at Exact Thresholds',
      category: 'Shipping Service',
      status: 'pending',
      expected: 'Exact ₹1,000 order charged ₹59; exact ₹3,000 order receives FREE shipping',
      actual: 'Pending test execution...',
      reproductionSteps: [
        '1. Form cart with exactly ₹1,000 subtotal.',
        '2. Check shipping fee: charges ₹99 instead of ₹59.',
        '3. Form cart with exactly ₹3,000 subtotal.',
        '4. Check shipping fee: charges ₹59 instead of ₹0 (FREE).',
      ],
      rootCause:
        'shippingService.ts: Boundary checks use `<=` instead of `<` (`cartSubtotal <= 1000` and `cartSubtotal <= 3000`).',
    },
    {
      id: 'BUG-08',
      name: 'Cart Variant Deserialization Loss on Browser Refresh',
      category: 'Cart Persistence',
      status: 'pending',
      expected: 'Selected variant options persist accurately after browser refresh or tab restore',
      actual: 'Pending test execution...',
      reproductionSteps: [
        '1. Add a product with a custom variant (e.g. 256GB Natural Titanium).',
        '2. Verify variant shows in cart.',
        '3. Refresh the page or reload from localStorage.',
        '4. Observe the variant name reverts to "Standard Edition" and variant metadata is cleared.',
      ],
      rootCause:
        'cartService.ts: loadFromStorage reads `rawItem.variant` instead of serialized `rawItem.selectedVariant`.',
    },
    {
      id: 'BUG-09',
      name: 'Variant Price Modifier Omission in Cart Payload',
      category: 'Variant Engine',
      status: 'pending',
      expected: 'Upgraded variant with +₹20,000 modifier is priced at ₹99,999 in cart',
      actual: 'Pending test execution...',
      reproductionSteps: [
        '1. Open "Apex Phone 16 Pro Max" (Base: ₹79,999).',
        '2. Select "512GB Space Black" (+₹20,000 upgrade, displays ₹99,999).',
        '3. Click "Add to Cart" and open Shopping Cart.',
        '4. Notice item is charged at base ₹79,999 price (modifier ignored).',
      ],
      rootCause:
        'cartService.ts: createCartItem explicitly checks `selectedVariant.type === "storage"` and assigns `product.discountPrice` without adding `priceModifier`.',
    },
    {
      id: 'BUG-10',
      name: 'Checkout Total Divergence from Cart Grand Total',
      category: 'Checkout Service',
      status: 'pending',
      expected: 'Grand Total on Checkout Step 3 matches Grand Total on Cart Page exactly',
      actual: 'Pending test execution...',
      reproductionSteps: [
        '1. Add items to cart and apply a discount coupon (e.g. SAVE500 or SAVE10).',
        '2. Note the Cart Grand Total.',
        '3. Proceed to Checkout and advance to Step 3 (Review) or Step 4.',
        '4. Observe Checkout Grand Total is lower because tax is recalculated on (subtotal - discount) instead of subtotal.',
      ],
      rootCause:
        'checkoutService.ts: computeCheckoutSummary calculates tax as `Math.round((subtotal - discount) * 0.18)` whereas cartService computes `Math.round(subtotal * 0.18)`.',
    },
    {
      id: 'BUG-11',
      name: 'Expired Coupon Acceptance via Inverted Date Comparison',
      category: 'Coupon Service',
      status: 'pending',
      expected: 'Coupon EXPIRED20 (expired Jan 1, 2024) is rejected with expiration error',
      actual: 'Pending test execution...',
      reproductionSteps: [
        '1. In Cart, enter expired code "EXPIRED20".',
        '2. Click "Apply".',
        '3. Observe the coupon is accepted and grants 20% discount!',
      ],
      rootCause:
        'couponService.ts: Date check uses inverted `new Date(coupon.expiryDate).getTime() > Date.now()`.',
    },
    {
      id: 'BUG-12',
      name: 'Shipping Address Pincode Mandatory Validation Bypass',
      category: 'Checkout Validation',
      status: 'pending',
      expected: 'Leaving Postal Pincode blank blocks advancing to Step 3 with validation error',
      actual: 'Pending test execution...',
      reproductionSteps: [
        '1. Proceed to Checkout Step 2 (Shipping Address).',
        '2. Clear the Pincode input field completely (leave empty).',
        '3. Click "Continue to Order Review".',
        '4. Form submits successfully and advances without requiring pincode.',
      ],
      rootCause:
        'checkoutService.ts: validateShippingAddress only checks length `if (address.pincode && ...)` and omits mandatory presence check when empty.',
    },
  ]);

  // Automated Test Runner Function
  const runAllDiagnostics = () => {
    setIsRunningAll(true);

    const updated = testResults.map((test) => {
      let passed = false;
      let actual = '';

      switch (test.id) {
        case 'BUG-01': {
          // Test quantity multiplier
          const sampleItem = cartService.createCartItem(
            productService.getAllProducts()[0],
            undefined,
            1
          );
          const updatedList = cartService.updateItemQuantity([sampleItem], sampleItem.cartItemId, 3);
          const calculatedSubtotal = updatedList[0].subtotal;
          const expectedSubtotal = sampleItem.unitPrice * 3;
          if (calculatedSubtotal !== expectedSubtotal) {
            actual = `DEFECT CONFIRMED: For qty 3, subtotal is ₹${calculatedSubtotal} (calculated for qty 2) instead of ₹${expectedSubtotal}`;
            passed = false; // "failed" in quality terms means defect is present and caught!
          } else {
            actual = 'Calculated correctly';
            passed = true;
          }
          break;
        }

        case 'BUG-02': {
          const sample = cartService.createCartItem(productService.getAllProducts()[0]);
          const state = { items: [sample], residualOffset: 0 };
          const { nextResidual } = cartService.removeItem(state, sample.cartItemId);
          if (nextResidual > 0) {
            actual = `DEFECT CONFIRMED: Residual offset retained ₹${nextResidual} (20% of removed item price)`;
            passed = false;
          } else {
            actual = 'Zero residual';
            passed = true;
          }
          break;
        }

        case 'BUG-03': {
          const product = productService.getProductById('prod-laptop-4')!; // SwiftBook Go 15 (MRP 42999, selling 34999)
          const item = cartService.createCartItem(product);
          const res = couponService.validateAndApply('WELCOME15', product.discountPrice, [item]);
          const expectedOnSelling = Math.min(1000, Math.round(product.discountPrice * 0.15));
          if (res.discountAmount !== expectedOnSelling) {
            actual = `DEFECT CONFIRMED: WELCOME15 gave ₹${res.discountAmount} discount (computed against MRP ₹${product.price} instead of selling ₹${product.discountPrice})`;
            passed = false;
          } else {
            actual = 'Computed against selling subtotal';
            passed = true;
          }
          break;
        }

        case 'BUG-04': {
          const prods = productService.getAllProducts();
          const results = searchService.search(prods, 'laptop');
          const firstResult = results[0];
          if (firstResult && firstResult.category !== 'Laptops') {
            actual = `DEFECT CONFIRMED: Searching "laptop" returned "${firstResult.name}" (${firstResult.category}) at position #1`;
            passed = false;
          } else {
            actual = 'Laptops ranked first';
            passed = true;
          }
          break;
        }

        case 'BUG-05': {
          const gamepad = productService.getProductById('prod-gaming-1')!; // price 5499, discountPrice 4299
          const filtered = filterService.filter([gamepad], { priceRange: 'under-5000' });
          if (filtered.length === 0) {
            actual = `DEFECT CONFIRMED: Item with selling price ₹${gamepad.discountPrice} excluded from "Under ₹5,000" because MRP is ₹${gamepad.price}`;
            passed = false;
          } else {
            actual = 'Included in filter';
            passed = true;
          }
          break;
        }

        case 'BUG-06': {
          const hp = productService.getProductById('prod-headphone-1')!;
          const oosVariant = hp.variants.find((v) => v.stockQuantity === 0);
          // Check if parent inStock is true while variant is 0
          if (hp.inStock && oosVariant && oosVariant.stockQuantity === 0) {
            actual = `DEFECT CONFIRMED: Variant "${oosVariant.name}" has stock 0, but parent.inStock is true, allowing bypass on detail page`;
            passed = false;
          } else {
            actual = 'Properly blocked';
            passed = true;
          }
          break;
        }

        case 'BUG-07': {
          const shippingAt1000 = shippingService.calculateShipping(1000);
          const shippingAt3000 = shippingService.calculateShipping(3000);
          if (shippingAt1000 === 99 || shippingAt3000 === 59) {
            actual = `DEFECT CONFIRMED: Subtotal ₹1,000 charged ₹${shippingAt1000} (expected ₹59); Subtotal ₹3,000 charged ₹${shippingAt3000} (expected ₹0 FREE)`;
            passed = false;
          } else {
            actual = 'Boundary correct';
            passed = true;
          }
          break;
        }

        case 'BUG-08': {
          const p = productService.getAllProducts()[0];
          const variant = p.variants[1];
          const item = cartService.createCartItem(p, variant);
          cartService.saveToStorage({ items: [item], residualOffset: 0 });
          const restored = cartService.loadFromStorage();
          if (!restored.items[0]?.selectedVariant) {
            actual = `DEFECT CONFIRMED: Restored cart item lost selectedVariant attribute (undefined) due to property key typo in deserializer`;
            passed = false;
          } else {
            actual = 'Variant restored';
            passed = true;
          }
          break;
        }

        case 'BUG-09': {
          const phone = productService.getProductById('prod-phone-1')!;
          const upgraded = phone.variants.find((v) => v.priceModifier > 0);
          if (upgraded) {
            const cartItem = cartService.createCartItem(phone, upgraded);
            if (cartItem.unitPrice === phone.discountPrice) {
              actual = `DEFECT CONFIRMED: Cart item unitPrice is ₹${cartItem.unitPrice} (omitted +₹${upgraded.priceModifier} modifier for storage variant)`;
              passed = false;
            } else {
              actual = 'Modifier added';
              passed = true;
            }
          }
          break;
        }

        case 'BUG-10': {
          const baseSummary = {
            subtotal: 10000,
            discount: 1000,
            shipping: 0,
            tax: 1800, // 18% on 10000
            grandTotal: 10800,
            itemCount: 1,
          };
          const checkoutSum = checkoutService.computeCheckoutSummary(baseSummary);
          if (checkoutSum.grandTotal !== baseSummary.grandTotal) {
            actual = `DEFECT CONFIRMED: Cart total ₹${baseSummary.grandTotal} vs Checkout total ₹${checkoutSum.grandTotal} (Tax divergence: ₹${baseSummary.tax} vs ₹${checkoutSum.tax})`;
            passed = false;
          } else {
            actual = 'Totals match';
            passed = true;
          }
          break;
        }

        case 'BUG-11': {
          const res = couponService.validateAndApply('EXPIRED20', 3000, []);
          if (res.isValid) {
            actual = `DEFECT CONFIRMED: Officially expired coupon "EXPIRED20" (expiry 2024-01-01) was successfully accepted due to inverted relational operator`;
            passed = false;
          } else {
            actual = 'Expired coupon blocked';
            passed = true;
          }
          break;
        }

        case 'BUG-12': {
          const res = checkoutService.validateShippingAddress({
            street: '123 Tech Lane',
            city: 'Bengaluru',
            state: 'Karnataka',
            pincode: '', // Empty pincode
          });
          if (res.isValid) {
            actual = `DEFECT CONFIRMED: validateShippingAddress accepted empty pincode "" without validation error`;
            passed = false;
          } else {
            actual = 'Blocked empty pincode';
            passed = true;
          }
          break;
        }
      }

      return {
        ...test,
        status: passed ? ('passed' as const) : ('failed' as const),
        actual,
      };
    });

    setTestResults(updated);
    setIsRunningAll(false);
  };

  // Seed standard test cart
  const seedStandardTestCart = () => {
    clearCart();
    const phone = productService.getProductById('prod-phone-1')!;
    const buds = productService.getProductById('prod-headphone-2')!;
    addItem(phone, phone.variants[0], 1);
    addItem(buds, buds.variants[0], 2);
  };

  const detectedDefectsCount = testResults.filter((t) => t.status === 'failed').length;

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* QA Header */}
      <div className="bg-slate-900 text-white p-6 sm:p-8 rounded-2xl border border-slate-800 mb-8 shadow-xl">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
          <div className="space-y-2">
            <div className="inline-flex items-center gap-1.5 text-xs font-mono font-bold text-amber-400 bg-amber-950/80 border border-amber-800 px-2.5 py-1 rounded">
              <ShieldCheck className="w-3.5 h-3.5" />
              <span>QA AUTOMATION & TRIAGE SUITE</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight">
              Software Testing & Bug Detection Challenge Console
            </h1>
            <p className="text-xs sm:text-sm text-slate-300 max-w-2xl leading-relaxed">
              Autonomous testing harness for AI QA agents and engineers. Run live diagnostics against
              the 12 seeded software defects, inspect internal application states, and reproduce bug triggers.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            <button
              onClick={runAllDiagnostics}
              disabled={isRunningAll}
              className="px-5 py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold uppercase tracking-wider rounded-xl transition-all shadow-md flex items-center gap-2"
            >
              <Play className="w-3.5 h-3.5 fill-current" />
              <span>{isRunningAll ? 'Running Tests...' : 'Run All 12 Automated Tests'}</span>
            </button>

            <button
              onClick={seedStandardTestCart}
              className="px-4 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold rounded-xl border border-slate-700 transition-colors"
            >
              Seed Test Cart
            </button>

            <button
              onClick={clearCart}
              className="px-4 py-2.5 bg-rose-950/60 hover:bg-rose-900/60 text-rose-300 text-xs font-semibold rounded-xl border border-rose-800/80 transition-colors"
            >
              Reset Storage
            </button>
          </div>
        </div>

        {/* Status Metrics Bar */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 pt-6 mt-6 border-t border-slate-800 text-xs">
          <div>
            <span className="text-slate-400 block font-mono">TARGET DEFECTS</span>
            <span className="text-xl font-bold font-mono text-white tabular-nums mt-0.5 block">
              12 Seeded Bugs
            </span>
          </div>

          <div>
            <span className="text-slate-400 block font-mono">DETECTED IN RUN</span>
            <span className="text-xl font-bold font-mono text-amber-400 tabular-nums mt-0.5 block">
              {detectedDefectsCount} Confirmed
            </span>
          </div>

          <div>
            <span className="text-slate-400 block font-mono">ACTIVE CART ITEMS</span>
            <span className="text-xl font-bold font-mono text-white tabular-nums mt-0.5 block">
              {items.length} ({summary.itemCount} units)
            </span>
          </div>

          <div>
            <span className="text-slate-400 block font-mono">GHOST RESIDUAL OFFSET</span>
            <span className="text-xl font-bold font-mono text-rose-400 tabular-nums mt-0.5 block">
              ₹{residualOffset}
            </span>
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex items-center gap-2 border-b border-slate-200 pb-4 mb-6">
        <button
          onClick={() => setActiveTab('diagnostics')}
          className={`px-4 py-2 text-xs font-bold rounded-lg transition-colors ${
            activeTab === 'diagnostics'
              ? 'bg-slate-900 text-white'
              : 'text-slate-600 hover:bg-slate-100'
          }`}
        >
          Automated Bug Scanner ({testResults.length})
        </button>

        <button
          onClick={() => setActiveTab('inspector')}
          className={`px-4 py-2 text-xs font-bold rounded-lg transition-colors ${
            activeTab === 'inspector'
              ? 'bg-slate-900 text-white'
              : 'text-slate-600 hover:bg-slate-100'
          }`}
        >
          Live State & Storage Inspector
        </button>

        <button
          onClick={() => setActiveTab('rules')}
          className={`px-4 py-2 text-xs font-bold rounded-lg transition-colors ${
            activeTab === 'rules'
              ? 'bg-slate-900 text-white'
              : 'text-slate-600 hover:bg-slate-100'
          }`}
        >
          Business Rules Specification
        </button>
      </div>

      {/* TAB 1: Diagnostics Runner */}
      {activeTab === 'diagnostics' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between text-xs text-slate-500 pb-2">
            <span>Click any test row to inspect reproduction steps, root cause, and logic defects.</span>
            <button
              onClick={runAllDiagnostics}
              className="text-indigo-600 font-semibold hover:underline"
            >
              Re-execute Suite
            </button>
          </div>

          <div className="bg-white rounded-xl border border-slate-200 overflow-hidden divide-y divide-slate-100 shadow-xs">
            {testResults.map((test) => {
              const isExpanded = expandedBugId === test.id;
              const isDefect = test.status === 'failed';

              return (
                <div key={test.id} className="transition-colors">
                  <div
                    onClick={() => setExpandedBugId(isExpanded ? null : test.id)}
                    className="p-4 flex items-center justify-between cursor-pointer hover:bg-slate-50/80 gap-4"
                  >
                    <div className="flex items-center gap-3">
                      {test.status === 'pending' ? (
                        <div className="w-6 h-6 rounded-full bg-slate-100 text-slate-400 flex items-center justify-center text-xs font-mono">
                          ?
                        </div>
                      ) : isDefect ? (
                        <div className="w-6 h-6 rounded-full bg-rose-100 text-rose-600 flex items-center justify-center">
                          <XCircle className="w-4 h-4" />
                        </div>
                      ) : (
                        <div className="w-6 h-6 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center">
                          <CheckCircle className="w-4 h-4" />
                        </div>
                      )}

                      <div>
                        <div className="flex items-center gap-2">
                          <span className="font-mono text-xs font-bold text-slate-900">
                            {test.id}
                          </span>
                          <span className="text-slate-300">·</span>
                          <span className="text-xs font-bold text-slate-800">
                            {test.name}
                          </span>
                          <span className="text-[10px] font-semibold text-slate-400 px-1.5 py-0.5 rounded bg-slate-100 uppercase tracking-wider font-mono">
                            {test.category}
                          </span>
                        </div>
                        <p className="text-xs text-slate-500 mt-0.5 line-clamp-1">
                          {test.status === 'pending' ? test.expected : test.actual}
                        </p>
                      </div>
                    </div>

                    <div className="flex items-center gap-4 shrink-0">
                      <span
                        className={`text-xs font-mono font-bold px-2 py-0.5 rounded ${
                          test.status === 'pending'
                            ? 'bg-slate-100 text-slate-600'
                            : isDefect
                            ? 'bg-rose-50 text-rose-700 border border-rose-200'
                            : 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                        }`}
                      >
                        {test.status === 'pending'
                          ? 'PENDING'
                          : isDefect
                          ? 'DEFECT CONFIRMED'
                          : 'PASS'}
                      </span>
                      {isExpanded ? (
                        <ChevronDown className="w-4 h-4 text-slate-400" />
                      ) : (
                        <ChevronRight className="w-4 h-4 text-slate-400" />
                      )}
                    </div>
                  </div>

                  {/* Expanded Detail Panel */}
                  {isExpanded && (
                    <div className="p-5 bg-slate-50 border-t border-slate-100 text-xs space-y-4">
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div className="p-3 bg-white rounded-lg border border-slate-200">
                          <span className="font-bold text-slate-700 uppercase tracking-wider block mb-1">
                            Expected Behavior (Business Contract)
                          </span>
                          <p className="text-slate-600 leading-relaxed">{test.expected}</p>
                        </div>

                        <div className="p-3 bg-white rounded-lg border border-slate-200">
                          <span className="font-bold text-slate-700 uppercase tracking-wider block mb-1">
                            Actual Test Observation
                          </span>
                          <p className="text-slate-900 font-mono leading-relaxed">{test.actual}</p>
                        </div>
                      </div>

                      <div className="p-3 bg-white rounded-lg border border-slate-200">
                        <span className="font-bold text-slate-700 uppercase tracking-wider block mb-2">
                          Exact Manual Reproduction Steps
                        </span>
                        <ol className="space-y-1 text-slate-600 pl-4 list-decimal">
                          {test.reproductionSteps.map((step, idx) => (
                            <li key={idx}>{step}</li>
                          ))}
                        </ol>
                      </div>

                      <div className="p-3 bg-slate-900 text-slate-200 rounded-lg font-mono">
                        <span className="text-indigo-400 font-bold uppercase tracking-wider block mb-1">
                          Source Root Cause
                        </span>
                        <code>{test.rootCause}</code>
                      </div>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* TAB 2: Live State Inspector */}
      {activeTab === 'inspector' && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Live Cart State */}
            <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs">
              <h3 className="text-xs font-bold uppercase tracking-wider text-slate-900 mb-3 flex items-center gap-2">
                <Database className="w-4 h-4 text-indigo-600" />
                <span>Live Cart State (In-Memory)</span>
              </h3>
              <pre className="p-4 bg-slate-900 text-slate-200 rounded-lg text-xs font-mono overflow-x-auto max-h-80">
                {JSON.stringify(
                  {
                    items,
                    summary,
                    residualOffset,
                    couponCode,
                  },
                  null,
                  2
                )}
              </pre>
            </div>

            {/* LocalStorage Dump */}
            <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs">
              <h3 className="text-xs font-bold uppercase tracking-wider text-slate-900 mb-3 flex items-center gap-2">
                <Code2 className="w-4 h-4 text-indigo-600" />
                <span>Browser LocalStorage Snapshot</span>
              </h3>
              <pre className="p-4 bg-slate-900 text-slate-200 rounded-lg text-xs font-mono overflow-x-auto max-h-80">
                {JSON.stringify(
                  {
                    nexpulse_cart_v1: JSON.parse(
                      localStorage.getItem('nexpulse_cart_v1') || '[]'
                    ),
                    nexpulse_cart_residual: localStorage.getItem('nexpulse_cart_residual'),
                    nexpulse_coupon: localStorage.getItem('nexpulse_coupon'),
                    nexpulse_latest_order: JSON.parse(
                      localStorage.getItem('nexpulse_latest_order') || 'null'
                    ),
                  },
                  null,
                  2
                )}
              </pre>
            </div>
          </div>

          {/* Coupon Database Dump */}
          <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs">
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-900 mb-3">
              Coupons Registered in Engine
            </h3>
            <div className="overflow-x-auto">
              <table className="w-full text-xs text-left">
                <thead className="bg-slate-50 text-slate-500 font-semibold border-b border-slate-200">
                  <tr>
                    <th className="p-2.5">Code</th>
                    <th className="p-2.5">Discount</th>
                    <th className="p-2.5">Min Order</th>
                    <th className="p-2.5">Expiry Date</th>
                    <th className="p-2.5">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {COUPON_DATABASE.map((c) => (
                    <tr key={c.code}>
                      <td className="p-2.5 font-mono font-bold text-indigo-600">{c.code}</td>
                      <td className="p-2.5 font-mono">
                        {c.type === 'percentage' ? `${c.value}%` : `₹${c.value}`}
                      </td>
                      <td className="p-2.5 font-mono">₹{c.minOrderValue}</td>
                      <td className="p-2.5 font-mono text-slate-500">{c.expiryDate}</td>
                      <td className="p-2.5">
                        {new Date(c.expiryDate).getTime() < Date.now() ? (
                          <span className="text-rose-600 font-semibold">Officially Expired</span>
                        ) : (
                          <span className="text-emerald-600 font-semibold">Active</span>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* TAB 3: Business Rules Specification */}
      {activeTab === 'rules' && (
        <div className="bg-white p-6 rounded-xl border border-slate-200 space-y-6 text-xs text-slate-700 shadow-xs">
          <div>
            <h2 className="text-sm font-bold uppercase tracking-wider text-slate-900 mb-2">
              1. Shipping Fee Schedule
            </h2>
            <ul className="space-y-1 list-disc pl-5">
              <li>Orders ₹0 to ₹999: ₹99 Shipping Charge</li>
              <li>Orders ₹1,000 to ₹2,999: ₹59 Shipping Charge</li>
              <li>Orders ₹3,000 and above: FREE Shipping (₹0)</li>
            </ul>
          </div>

          <div>
            <h2 className="text-sm font-bold uppercase tracking-wider text-slate-900 mb-2">
              2. Coupon Validation & Maximum Caps
            </h2>
            <ul className="space-y-1 list-disc pl-5">
              <li>SAVE10: 10% discount on order value above ₹1,000</li>
              <li>SAVE500: Flat ₹500 discount on order value above ₹5,000</li>
              <li>WELCOME15: 15% discount up to ₹1,000 max on order value above ₹500</li>
              <li>EXPIRED20: Expired on 2024-01-01 (should NOT be accepted)</li>
            </ul>
          </div>

          <div>
            <h2 className="text-sm font-bold uppercase tracking-wider text-slate-900 mb-2">
              3. Tax & Subtotal Computation
            </h2>
            <ul className="space-y-1 list-disc pl-5">
              <li>Cart Subtotal = Sum of (Item Unit Price × Quantity)</li>
              <li>GST = 18% of merchandise subtotal</li>
              <li>Grand Total = Subtotal - Discount + Shipping + Tax</li>
            </ul>
          </div>
        </div>
      )}
    </div>
  );
};
