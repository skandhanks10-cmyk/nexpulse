import React, { useState } from 'react';
import {
  Trash2,
  ArrowRight,
  ArrowLeft,
  Tag,
  Truck,
  CheckCircle2,
  AlertCircle,
  ShoppingBag,
} from 'lucide-react';
import { useCart } from '../context/CartContext';
import { shippingService } from '../services/shippingService';
import { couponService } from '../services/couponService';

interface CartPageProps {
  onContinueShopping: () => void;
  onProceedToCheckout: () => void;
  onSelectProduct: (productId: string) => void;
}

export const CartPage: React.FC<CartPageProps> = ({
  onContinueShopping,
  onProceedToCheckout,
  onSelectProduct,
}) => {
  const {
    items,
    summary,
    couponCode,
    updateQuantity,
    removeItem,
    applyCoupon,
    removeCoupon,
  } = useCart();

  const [inputCoupon, setInputCoupon] = useState('');
  const [couponMessage, setCouponMessage] = useState<{
    text: string;
    isError: boolean;
  } | null>(null);

  const shippingInfo = shippingService.getShippingStatusMessage(summary.subtotal);
  const availableCoupons = couponService.getAvailableCoupons();

  const handleApplyCoupon = (codeToApply?: string) => {
    const code = codeToApply || inputCoupon;
    if (!code.trim()) return;

    const res = applyCoupon(code);
    setCouponMessage({
      text: res.message,
      isError: !res.success,
    });
    if (res.success) {
      setInputCoupon('');
    }
  };

  const handleRemoveCoupon = () => {
    removeCoupon();
    setCouponMessage(null);
  };

  if (items.length === 0) {
    return (
      <div className="max-w-4xl mx-auto px-4 py-16 text-center">
        <div className="w-16 h-16 bg-slate-100 rounded-full flex items-center justify-center mx-auto mb-4 text-slate-400">
          <ShoppingBag className="w-8 h-8" />
        </div>
        <h2 className="text-2xl font-bold text-slate-900 tracking-tight">
          Your Shopping Cart is Empty
        </h2>
        <p className="text-sm text-slate-500 mt-2 mb-6 max-w-md mx-auto">
          Explore our collection of flagship smartphones, creator laptops, noise-cancelling audio, and gaming gear.
        </p>
        <button
          onClick={onContinueShopping}
          className="px-6 py-3 text-sm font-bold text-white bg-slate-900 hover:bg-slate-800 rounded-lg transition-colors inline-flex items-center gap-2"
        >
          <span>Explore Products</span>
          <ArrowRight className="w-4 h-4" />
        </button>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Page Title */}
      <div className="flex items-center justify-between pb-6 border-b border-slate-200 mb-8">
        <div>
          <h1 className="text-3xl font-extrabold text-slate-900 tracking-tight">
            Shopping Cart
          </h1>
          <p className="text-xs text-slate-500 mt-1 font-mono">
            {summary.itemCount} items · Free delivery over ₹3,000
          </p>
        </div>

        <button
          onClick={onContinueShopping}
          className="text-xs font-semibold text-slate-600 hover:text-slate-900 flex items-center gap-1"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Continue Shopping</span>
        </button>
      </div>

      {/* Free Delivery Progress Bar */}
      <div className="bg-white p-4 rounded-xl border border-slate-200 mb-8 shadow-xs">
        <div className="flex items-center justify-between text-xs font-semibold mb-2">
          <div className="flex items-center gap-2 text-slate-800">
            <Truck className="w-4 h-4 text-indigo-600" />
            <span>{shippingInfo.message}</span>
          </div>
          <span className="font-mono text-indigo-600 tabular-nums">
            {shippingInfo.progress}%
          </span>
        </div>
        <div className="w-full bg-slate-100 rounded-full h-2 overflow-hidden">
          <div
            className="bg-indigo-600 h-full rounded-full transition-all duration-300"
            style={{ width: `${shippingInfo.progress}%` }}
          />
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Left Column: Cart Items List */}
        <div className="lg:col-span-8 space-y-4">
          <div className="bg-white rounded-xl border border-slate-200 overflow-hidden divide-y divide-slate-100">
            {items.map((item) => (
              <div
                key={item.cartItemId}
                className="p-5 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 group"
              >
                {/* Item Details */}
                <div className="flex items-center gap-4 flex-1">
                  <div
                    onClick={() => onSelectProduct(item.productId)}
                    className="w-20 h-20 bg-slate-100 rounded-lg overflow-hidden shrink-0 cursor-pointer border border-slate-200"
                  >
                    {item.image ? (
                      <img
                        src={item.image}
                        alt={item.name}
                        referrerPolicy="no-referrer"
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform"
                      />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center text-slate-400">
                        <ShoppingBag className="w-6 h-6" />
                      </div>
                    )}
                  </div>

                  <div>
                    <span className="text-[11px] font-semibold uppercase tracking-wider text-slate-400 block">
                      {item.brand}
                    </span>
                    <h3
                      onClick={() => onSelectProduct(item.productId)}
                      className="text-sm font-bold text-slate-900 hover:text-indigo-600 transition-colors cursor-pointer line-clamp-1"
                    >
                      {item.name}
                    </h3>
                    {item.selectedVariant ? (
                      <span className="text-xs text-indigo-700 bg-indigo-50 px-2 py-0.5 rounded font-medium mt-1 inline-block">
                        {item.selectedVariant.name}
                      </span>
                    ) : (
                      <span className="text-xs text-slate-400 mt-1 inline-block">
                        Standard Edition
                      </span>
                    )}

                    <div className="text-xs font-mono font-semibold text-slate-600 mt-1 tabular-nums">
                      ₹{item.unitPrice.toLocaleString('en-IN')} each
                    </div>
                  </div>
                </div>

                {/* Quantity Controls & Line Item Subtotal */}
                <div className="flex items-center justify-between sm:justify-end gap-6 w-full sm:w-auto pt-2 sm:pt-0 border-t sm:border-t-0 border-slate-100">
                  {/* Stepper */}
                  <div className="flex items-center border border-slate-200 rounded-lg bg-slate-50 overflow-hidden">
                    <button
                      type="button"
                      onClick={() => updateQuantity(item.cartItemId, item.quantity - 1)}
                      className="px-2.5 py-1 text-slate-600 hover:bg-slate-200 font-bold transition-colors"
                    >
                      -
                    </button>
                    <span className="px-3 py-1 text-xs font-mono font-bold text-slate-900 tabular-nums">
                      {item.quantity}
                    </span>
                    <button
                      type="button"
                      onClick={() => updateQuantity(item.cartItemId, item.quantity + 1)}
                      className="px-2.5 py-1 text-slate-600 hover:bg-slate-200 font-bold transition-colors"
                    >
                      +
                    </button>
                  </div>

                  {/* Subtotal */}
                  <div className="text-right min-w-24">
                    <div className="text-sm font-bold font-mono text-slate-900 tabular-nums">
                      ₹{item.subtotal.toLocaleString('en-IN')}
                    </div>
                    {item.quantity >= 3 && (
                      <span className="text-[10px] text-amber-600 font-medium block">
                        Bulk Tier Applied
                      </span>
                    )}
                  </div>

                  {/* Remove Button */}
                  <button
                    type="button"
                    onClick={() => removeItem(item.cartItemId)}
                    className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors"
                    title="Remove item"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))}
          </div>

          {/* Available Coupons Banner for Quick Testing */}
          <div className="bg-slate-50 border border-slate-200 rounded-xl p-4">
            <div className="flex items-center gap-2 text-xs font-bold text-slate-700 uppercase tracking-wider mb-2">
              <Tag className="w-3.5 h-3.5 text-indigo-600" />
              <span>Available Promotional Codes</span>
            </div>
            <div className="flex flex-wrap gap-2">
              {availableCoupons.map((c) => (
                <button
                  key={c.code}
                  type="button"
                  onClick={() => handleApplyCoupon(c.code)}
                  className="px-2.5 py-1 text-xs font-mono font-semibold bg-white border border-slate-200 hover:border-indigo-400 text-slate-800 rounded-md transition-colors shadow-xs"
                >
                  {c.code} <span className="text-slate-400 font-normal">({c.description})</span>
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Right Column: Coupon Input & Cart Summary */}
        <div className="lg:col-span-4 space-y-6">
          {/* Coupon Input Box */}
          <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs">
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-900 mb-3 flex items-center gap-1.5">
              <Tag className="w-3.5 h-3.5 text-indigo-600" />
              <span>Apply Discount Coupon</span>
            </h3>

            {couponCode ? (
              <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-lg flex items-center justify-between text-xs">
                <div>
                  <span className="font-mono font-bold text-emerald-900">{couponCode}</span>
                  <span className="text-emerald-700 block">
                    -₹{summary.discount.toLocaleString('en-IN')} discount applied
                  </span>
                </div>
                <button
                  type="button"
                  onClick={handleRemoveCoupon}
                  className="text-xs font-semibold text-rose-600 hover:underline"
                >
                  Remove
                </button>
              </div>
            ) : (
              <div className="flex gap-2">
                <input
                  type="text"
                  value={inputCoupon}
                  onChange={(e) => setInputCoupon(e.target.value.toUpperCase())}
                  placeholder="Enter code (e.g. SAVE10)"
                  className="flex-1 px-3 py-2 text-xs font-mono uppercase bg-slate-50 border border-slate-200 rounded-lg text-slate-900 focus:outline-none focus:ring-1 focus:ring-indigo-500"
                />
                <button
                  type="button"
                  onClick={() => handleApplyCoupon()}
                  className="px-4 py-2 text-xs font-bold text-white bg-slate-900 hover:bg-slate-800 rounded-lg transition-colors shadow-xs"
                >
                  Apply
                </button>
              </div>
            )}

            {couponMessage && (
              <div
                className={`mt-3 text-xs flex items-start gap-1.5 p-2.5 rounded-lg ${
                  couponMessage.isError
                    ? 'bg-rose-50 text-rose-700 border border-rose-200'
                    : 'bg-emerald-50 text-emerald-800 border border-emerald-200'
                }`}
              >
                {couponMessage.isError ? (
                  <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
                ) : (
                  <CheckCircle2 className="w-4 h-4 shrink-0 mt-0.5" />
                )}
                <span>{couponMessage.text}</span>
              </div>
            )}
          </div>

          {/* Cart Financial Summary Box */}
          <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-xs space-y-4">
            <h3 className="text-sm font-bold uppercase tracking-wider text-slate-900 pb-3 border-b border-slate-100">
              Order Summary
            </h3>

            <div className="space-y-2.5 text-xs">
              <div className="flex justify-between text-slate-600">
                <span>Merchandise Subtotal</span>
                <span className="font-mono font-semibold text-slate-900 tabular-nums">
                  ₹{summary.subtotal.toLocaleString('en-IN')}
                </span>
              </div>

              {summary.discount > 0 && (
                <div className="flex justify-between text-emerald-600 font-medium">
                  <span>Coupon Discount ({couponCode})</span>
                  <span className="font-mono font-bold tabular-nums">
                    -₹{summary.discount.toLocaleString('en-IN')}
                  </span>
                </div>
              )}

              <div className="flex justify-between text-slate-600">
                <span>Shipping & Handling</span>
                <span className="font-mono font-semibold text-slate-900 tabular-nums">
                  {summary.shipping === 0 ? (
                    <span className="text-emerald-600 font-bold">FREE</span>
                  ) : (
                    `₹${summary.shipping.toLocaleString('en-IN')}`
                  )}
                </span>
              </div>

              <div className="flex justify-between text-slate-600">
                <span>Estimated Tax (18% GST)</span>
                <span className="font-mono font-semibold text-slate-900 tabular-nums">
                  ₹{summary.tax.toLocaleString('en-IN')}
                </span>
              </div>
            </div>

            <div className="pt-4 border-t border-slate-200 flex justify-between items-baseline">
              <div>
                <span className="text-sm font-bold text-slate-900">Grand Total</span>
                <span className="text-[11px] text-slate-400 block">All taxes inclusive</span>
              </div>
              <span className="text-2xl font-extrabold font-mono text-slate-900 tabular-nums">
                ₹{summary.grandTotal.toLocaleString('en-IN')}
              </span>
            </div>

            <button
              type="button"
              onClick={onProceedToCheckout}
              className="w-full py-3.5 px-4 bg-slate-900 hover:bg-slate-800 text-white text-sm font-bold rounded-xl flex items-center justify-center gap-2 transition-all shadow-md hover:shadow-lg mt-4"
            >
              <span>Proceed to Checkout</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
