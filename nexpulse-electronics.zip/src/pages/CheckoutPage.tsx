import React, { useState, useMemo } from 'react';
import {
  Check,
  ChevronRight,
  CreditCard,
  QrCode,
  Banknote,
  ShieldCheck,
  ArrowLeft,
  Lock,
  Loader2,
  AlertCircle,
} from 'lucide-react';
import { useCart } from '../context/CartContext';
import {
  CheckoutStep,
  CustomerInfo,
  PaymentDetails,
  PaymentMethod,
  ShippingAddress,
} from '../types';
import { checkoutService } from '../services/checkoutService';
import { orderService } from '../services/orderService';

interface CheckoutPageProps {
  onBackToCart: () => void;
  onOrderSuccess: (orderId: string) => void;
}

export const CheckoutPage: React.FC<CheckoutPageProps> = ({
  onBackToCart,
  onOrderSuccess,
}) => {
  const { items, summary: cartSummary, clearCart } = useCart();

  const [step, setStep] = useState<CheckoutStep>(1);

  // Form states with realistic default test values
  const [customerInfo, setCustomerInfo] = useState<CustomerInfo>({
    fullName: 'Rahul Sharma',
    email: 'rahul.sharma@example.com',
    phone: '9876543210',
  });

  const [shippingAddress, setShippingAddress] = useState<ShippingAddress>({
    street: 'Flat 402, Titanium Residency, Indiranagar',
    city: 'Bengaluru',
    state: 'Karnataka',
    pincode: '560038',
  });

  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>('card');
  const [cardDetails, setCardDetails] = useState({
    cardNumber: '4532 8923 1104 7721',
    expiry: '08/28',
    cvv: '842',
    cardHolder: 'RAHUL SHARMA',
  });
  const [upiId, setUpiId] = useState('rahulsharma@okhdfcbank');

  const [errors, setErrors] = useState<Record<string, string>>({});
  const [isProcessing, setIsProcessing] = useState(false);

  // INTENTIONAL DEFECT: BUG-10 (Checkout Total Mismatch)
  // Checkout recalculates summary with the bug where tax = (subtotal - discount) * 0.18
  const checkoutSummary = useMemo(() => {
    return checkoutService.computeCheckoutSummary(cartSummary);
  }, [cartSummary]);

  // Step 1 Validation & Proceed
  const handleProceedFromStep1 = (e: React.FormEvent) => {
    e.preventDefault();
    const result = checkoutService.validateCustomerInfo(customerInfo);
    if (!result.isValid) {
      setErrors(result.errors);
      return;
    }
    setErrors({});
    setStep(2);
  };

  // Step 2 Validation & Proceed (Triggers BUG-12 if pincode is blank)
  const handleProceedFromStep2 = (e: React.FormEvent) => {
    e.preventDefault();
    const result = checkoutService.validateShippingAddress(shippingAddress);
    if (!result.isValid) {
      setErrors(result.errors);
      return;
    }
    setErrors({});
    setStep(3);
  };

  // Step 3 Proceed to Payment
  const handleProceedFromStep3 = () => {
    setStep(4);
  };

  // Step 4 Simulated Payment Execution
  const handleExecutePayment = (e: React.FormEvent) => {
    e.preventDefault();

    const paymentDetails: PaymentDetails = {
      method: paymentMethod,
      cardDetails: paymentMethod === 'card' ? cardDetails : undefined,
      upiId: paymentMethod === 'upi' ? upiId : undefined,
    };

    const result = checkoutService.validatePayment(paymentDetails);
    if (!result.isValid) {
      setErrors(result.errors);
      return;
    }

    setErrors({});
    setIsProcessing(true);

    // Simulate 1.2s gateway communication
    setTimeout(() => {
      const createdOrder = orderService.createOrder({
        items,
        customerInfo,
        shippingAddress,
        paymentMethod,
        summary: checkoutSummary,
      });

      clearCart();
      setIsProcessing(false);
      onOrderSuccess(createdOrder.orderId);
    }, 1200);
  };

  if (items.length === 0 && !isProcessing) {
    return (
      <div className="max-w-xl mx-auto py-16 text-center">
        <h2 className="text-xl font-bold text-slate-900">Your cart is empty</h2>
        <button
          onClick={onBackToCart}
          className="mt-4 px-4 py-2 bg-slate-900 text-white rounded-lg text-xs font-semibold"
        >
          Return to Store
        </button>
      </div>
    );
  }

  const stepsList = [
    { num: 1, label: 'Customer' },
    { num: 2, label: 'Shipping' },
    { num: 3, label: 'Review' },
    { num: 4, label: 'Payment' },
  ];

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 py-8">
      {/* Back button */}
      <button
        onClick={onBackToCart}
        className="inline-flex items-center gap-1.5 text-xs font-semibold text-slate-600 hover:text-slate-900 mb-6"
      >
        <ArrowLeft className="w-4 h-4" />
        <span>Back to Shopping Cart</span>
      </button>

      {/* Stepper Progress Header */}
      <div className="mb-8">
        <div className="flex items-center justify-between max-w-2xl mx-auto relative">
          <div className="absolute top-1/2 left-0 right-0 h-0.5 bg-slate-200 -translate-y-1/2 z-0" />
          {stepsList.map((s) => {
            const isCompleted = step > s.num;
            const isCurrent = step === s.num;

            return (
              <div
                key={s.num}
                className="relative z-10 flex flex-col items-center cursor-pointer"
                onClick={() => {
                  if (s.num < step) setStep(s.num as CheckoutStep);
                }}
              >
                <div
                  className={`w-9 h-9 rounded-full flex items-center justify-center text-xs font-bold transition-all ${
                    isCompleted
                      ? 'bg-emerald-600 text-white shadow-sm'
                      : isCurrent
                      ? 'bg-slate-900 text-white ring-4 ring-slate-100 shadow-md'
                      : 'bg-white border-2 border-slate-300 text-slate-400'
                  }`}
                >
                  {isCompleted ? <Check className="w-4 h-4" /> : s.num}
                </div>
                <span
                  className={`text-xs font-semibold mt-1.5 ${
                    isCurrent ? 'text-slate-900' : 'text-slate-500'
                  }`}
                >
                  {s.label}
                </span>
              </div>
            );
          })}
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Step Forms */}
        <div className="lg:col-span-7 bg-white p-6 sm:p-8 rounded-2xl border border-slate-200 shadow-xs">
          {/* STEP 1: Customer Information */}
          {step === 1 && (
            <form onSubmit={handleProceedFromStep1} className="space-y-4">
              <h2 className="text-lg font-bold text-slate-900 pb-2 border-b border-slate-100">
                Step 1: Customer Information
              </h2>

              <div>
                <label className="text-xs font-bold uppercase tracking-wider text-slate-700 block mb-1">
                  Full Name *
                </label>
                <input
                  type="text"
                  value={customerInfo.fullName}
                  onChange={(e) =>
                    setCustomerInfo({ ...customerInfo, fullName: e.target.value })
                  }
                  className={`w-full px-3 py-2 text-sm bg-slate-50 border rounded-lg focus:outline-none focus:ring-1 ${
                    errors.fullName ? 'border-rose-500 bg-rose-50/30' : 'border-slate-200 focus:ring-indigo-500'
                  }`}
                  placeholder="e.g. Rahul Sharma"
                />
                {errors.fullName && (
                  <span className="text-xs text-rose-600 mt-1 block">{errors.fullName}</span>
                )}
              </div>

              <div>
                <label className="text-xs font-bold uppercase tracking-wider text-slate-700 block mb-1">
                  Email Address *
                </label>
                <input
                  type="email"
                  value={customerInfo.email}
                  onChange={(e) =>
                    setCustomerInfo({ ...customerInfo, email: e.target.value })
                  }
                  className={`w-full px-3 py-2 text-sm bg-slate-50 border rounded-lg focus:outline-none focus:ring-1 ${
                    errors.email ? 'border-rose-500 bg-rose-50/30' : 'border-slate-200 focus:ring-indigo-500'
                  }`}
                  placeholder="name@example.com"
                />
                {errors.email && (
                  <span className="text-xs text-rose-600 mt-1 block">{errors.email}</span>
                )}
              </div>

              <div>
                <label className="text-xs font-bold uppercase tracking-wider text-slate-700 block mb-1">
                  10-Digit Mobile Number *
                </label>
                <input
                  type="tel"
                  value={customerInfo.phone}
                  onChange={(e) =>
                    setCustomerInfo({ ...customerInfo, phone: e.target.value })
                  }
                  className={`w-full px-3 py-2 text-sm bg-slate-50 border rounded-lg focus:outline-none focus:ring-1 ${
                    errors.phone ? 'border-rose-500 bg-rose-50/30' : 'border-slate-200 focus:ring-indigo-500'
                  }`}
                  placeholder="9876543210"
                />
                {errors.phone && (
                  <span className="text-xs text-rose-600 mt-1 block">{errors.phone}</span>
                )}
              </div>

              <button
                type="submit"
                className="w-full mt-6 py-3 px-4 bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold uppercase tracking-wider rounded-xl transition-colors flex items-center justify-center gap-1.5"
              >
                <span>Continue to Shipping Address</span>
                <ChevronRight className="w-4 h-4" />
              </button>
            </form>
          )}

          {/* STEP 2: Shipping Address (Contains BUG-12: Pincode can be empty) */}
          {step === 2 && (
            <form onSubmit={handleProceedFromStep2} className="space-y-4">
              <div className="flex items-center justify-between pb-2 border-b border-slate-100">
                <h2 className="text-lg font-bold text-slate-900">
                  Step 2: Shipping Address
                </h2>
                <button
                  type="button"
                  onClick={() => setStep(1)}
                  className="text-xs text-indigo-600 hover:underline"
                >
                  Edit Customer Info
                </button>
              </div>

              <div>
                <label className="text-xs font-bold uppercase tracking-wider text-slate-700 block mb-1">
                  Street Address / Apartment *
                </label>
                <input
                  type="text"
                  value={shippingAddress.street}
                  onChange={(e) =>
                    setShippingAddress({ ...shippingAddress, street: e.target.value })
                  }
                  className={`w-full px-3 py-2 text-sm bg-slate-50 border rounded-lg focus:outline-none focus:ring-1 ${
                    errors.street ? 'border-rose-500 bg-rose-50/30' : 'border-slate-200 focus:ring-indigo-500'
                  }`}
                />
                {errors.street && (
                  <span className="text-xs text-rose-600 mt-1 block">{errors.street}</span>
                )}
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-xs font-bold uppercase tracking-wider text-slate-700 block mb-1">
                    City *
                  </label>
                  <input
                    type="text"
                    value={shippingAddress.city}
                    onChange={(e) =>
                      setShippingAddress({ ...shippingAddress, city: e.target.value })
                    }
                    className={`w-full px-3 py-2 text-sm bg-slate-50 border rounded-lg focus:outline-none focus:ring-1 ${
                      errors.city ? 'border-rose-500 bg-rose-50/30' : 'border-slate-200 focus:ring-indigo-500'
                    }`}
                  />
                  {errors.city && (
                    <span className="text-xs text-rose-600 mt-1 block">{errors.city}</span>
                  )}
                </div>

                <div>
                  <label className="text-xs font-bold uppercase tracking-wider text-slate-700 block mb-1">
                    State *
                  </label>
                  <input
                    type="text"
                    value={shippingAddress.state}
                    onChange={(e) =>
                      setShippingAddress({ ...shippingAddress, state: e.target.value })
                    }
                    className={`w-full px-3 py-2 text-sm bg-slate-50 border rounded-lg focus:outline-none focus:ring-1 ${
                      errors.state ? 'border-rose-500 bg-rose-50/30' : 'border-slate-200 focus:ring-indigo-500'
                    }`}
                  />
                  {errors.state && (
                    <span className="text-xs text-rose-600 mt-1 block">{errors.state}</span>
                  )}
                </div>
              </div>

              {/* Pincode field (BUG-12 testable: leaving empty bypasses validation) */}
              <div>
                <div className="flex items-center justify-between">
                  <label className="text-xs font-bold uppercase tracking-wider text-slate-700 block mb-1">
                    Postal Pincode *
                  </label>
                  <button
                    type="button"
                    onClick={() => setShippingAddress({ ...shippingAddress, pincode: '' })}
                    className="text-[11px] text-amber-700 hover:underline"
                    title="Clear pincode to test BUG-12 validation defect"
                  >
                    (Test: Clear Pincode)
                  </button>
                </div>
                <input
                  type="text"
                  value={shippingAddress.pincode}
                  onChange={(e) =>
                    setShippingAddress({ ...shippingAddress, pincode: e.target.value })
                  }
                  placeholder="e.g. 560038"
                  className={`w-full px-3 py-2 text-sm bg-slate-50 border rounded-lg focus:outline-none focus:ring-1 ${
                    errors.pincode ? 'border-rose-500 bg-rose-50/30' : 'border-slate-200 focus:ring-indigo-500'
                  }`}
                />
                {errors.pincode && (
                  <span className="text-xs text-rose-600 mt-1 block">{errors.pincode}</span>
                )}
              </div>

              <div className="flex gap-3 pt-4">
                <button
                  type="button"
                  onClick={() => setStep(1)}
                  className="px-4 py-3 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold rounded-xl transition-colors"
                >
                  Back
                </button>
                <button
                  type="submit"
                  className="flex-1 py-3 px-4 bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold uppercase tracking-wider rounded-xl transition-colors flex items-center justify-center gap-1.5"
                >
                  <span>Continue to Order Review</span>
                  <ChevronRight className="w-4 h-4" />
                </button>
              </div>
            </form>
          )}

          {/* STEP 3: Order Review (Contains BUG-10: Total differs from Cart) */}
          {step === 3 && (
            <div className="space-y-6">
              <div className="flex items-center justify-between pb-2 border-b border-slate-100">
                <h2 className="text-lg font-bold text-slate-900">
                  Step 3: Review Your Order
                </h2>
                <div className="flex gap-3 text-xs text-indigo-600">
                  <button onClick={() => setStep(1)} className="hover:underline">
                    Edit Customer
                  </button>
                  <span>·</span>
                  <button onClick={() => setStep(2)} className="hover:underline">
                    Edit Address
                  </button>
                </div>
              </div>

              {/* Shipping & Customer Details Summary */}
              <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 text-xs space-y-2">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <span className="font-bold text-slate-500 uppercase tracking-wider block">
                      Deliver To:
                    </span>
                    <span className="font-semibold text-slate-900 block mt-0.5">
                      {customerInfo.fullName}
                    </span>
                    <span className="text-slate-600">{customerInfo.phone}</span>
                  </div>
                  <div>
                    <span className="font-bold text-slate-500 uppercase tracking-wider block">
                      Address:
                    </span>
                    <span className="text-slate-800 block mt-0.5">
                      {shippingAddress.street}, {shippingAddress.city},{' '}
                      {shippingAddress.state} {shippingAddress.pincode ? `- ${shippingAddress.pincode}` : '(No Pincode Provided)'}
                    </span>
                  </div>
                </div>
              </div>

              {/* Items List in Checkout */}
              <div className="divide-y divide-slate-100 max-h-60 overflow-y-auto pr-2">
                {items.map((item) => (
                  <div key={item.cartItemId} className="py-3 flex items-center justify-between text-xs">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 bg-slate-100 rounded overflow-hidden shrink-0">
                        {item.image && (
                          <img src={item.image} alt={item.name} className="w-full h-full object-cover" />
                        )}
                      </div>
                      <div>
                        <span className="font-bold text-slate-900 line-clamp-1">{item.name}</span>
                        <span className="text-slate-500">
                          {item.selectedVariant?.name || 'Standard'} · Qty: {item.quantity}
                        </span>
                      </div>
                    </div>
                    <span className="font-mono font-bold text-slate-900 tabular-nums">
                      ₹{item.subtotal.toLocaleString('en-IN')}
                    </span>
                  </div>
                ))}
              </div>

              <div className="flex gap-3 pt-4 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setStep(2)}
                  className="px-4 py-3 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold rounded-xl transition-colors"
                >
                  Back
                </button>
                <button
                  type="button"
                  onClick={handleProceedFromStep3}
                  className="flex-1 py-3 px-4 bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold uppercase tracking-wider rounded-xl transition-colors flex items-center justify-center gap-1.5"
                >
                  <span>Proceed to Payment</span>
                  <ChevronRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          )}

          {/* STEP 4: Simulated Payment */}
          {step === 4 && (
            <form onSubmit={handleExecutePayment} className="space-y-6">
              <div className="flex items-center justify-between pb-2 border-b border-slate-100">
                <h2 className="text-lg font-bold text-slate-900">
                  Step 4: Simulated Payment
                </h2>
                <button
                  type="button"
                  onClick={() => setStep(3)}
                  className="text-xs text-indigo-600 hover:underline"
                >
                  Review Order
                </button>
              </div>

              {/* Payment Methods */}
              <div className="grid grid-cols-3 gap-3">
                {[
                  { id: 'card', label: 'Card Payment', icon: CreditCard },
                  { id: 'upi', label: 'UPI / QR', icon: QrCode },
                  { id: 'cod', label: 'Cash on Delivery', icon: Banknote },
                ].map((pm) => {
                  const Icon = pm.icon;
                  const isSelected = paymentMethod === pm.id;
                  return (
                    <button
                      key={pm.id}
                      type="button"
                      onClick={() => setPaymentMethod(pm.id as PaymentMethod)}
                      className={`p-3.5 rounded-xl border text-center flex flex-col items-center justify-center gap-2 transition-all ${
                        isSelected
                          ? 'border-indigo-600 bg-indigo-50/60 ring-1 ring-indigo-600 text-indigo-950 font-bold'
                          : 'border-slate-200 hover:border-slate-300 text-slate-600'
                      }`}
                    >
                      <Icon className="w-5 h-5" />
                      <span className="text-xs">{pm.label}</span>
                    </button>
                  );
                })}
              </div>

              {/* Method Detail Inputs */}
              {paymentMethod === 'card' && (
                <div className="space-y-3 pt-2">
                  <div>
                    <label className="text-xs font-bold uppercase tracking-wider text-slate-700 block mb-1">
                      16-Digit Card Number
                    </label>
                    <input
                      type="text"
                      value={cardDetails.cardNumber}
                      onChange={(e) =>
                        setCardDetails({ ...cardDetails, cardNumber: e.target.value })
                      }
                      className="w-full px-3 py-2 text-sm font-mono bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-1 focus:ring-indigo-500"
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="text-xs font-bold uppercase tracking-wider text-slate-700 block mb-1">
                        Expiry (MM/YY)
                      </label>
                      <input
                        type="text"
                        value={cardDetails.expiry}
                        onChange={(e) =>
                          setCardDetails({ ...cardDetails, expiry: e.target.value })
                        }
                        className="w-full px-3 py-2 text-sm font-mono bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-1 focus:ring-indigo-500"
                      />
                    </div>
                    <div>
                      <label className="text-xs font-bold uppercase tracking-wider text-slate-700 block mb-1">
                        CVV / CVC
                      </label>
                      <input
                        type="password"
                        maxLength={4}
                        value={cardDetails.cvv}
                        onChange={(e) =>
                          setCardDetails({ ...cardDetails, cvv: e.target.value })
                        }
                        className="w-full px-3 py-2 text-sm font-mono bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-1 focus:ring-indigo-500"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="text-xs font-bold uppercase tracking-wider text-slate-700 block mb-1">
                      Cardholder Name
                    </label>
                    <input
                      type="text"
                      value={cardDetails.cardHolder}
                      onChange={(e) =>
                        setCardDetails({ ...cardDetails, cardHolder: e.target.value })
                      }
                      className="w-full px-3 py-2 text-sm uppercase bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-1 focus:ring-indigo-500"
                    />
                  </div>
                </div>
              )}

              {paymentMethod === 'upi' && (
                <div className="space-y-3 pt-2">
                  <label className="text-xs font-bold uppercase tracking-wider text-slate-700 block mb-1">
                    Virtual Payment Address (UPI ID)
                  </label>
                  <input
                    type="text"
                    value={upiId}
                    onChange={(e) => setUpiId(e.target.value)}
                    placeholder="username@bank"
                    className="w-full px-3 py-2 text-sm font-mono bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-1 focus:ring-indigo-500"
                  />
                  <p className="text-xs text-slate-400">
                    A simulated collect approval will be dispatched to your UPI application.
                  </p>
                </div>
              )}

              {paymentMethod === 'cod' && (
                <div className="p-4 bg-amber-50 border border-amber-200 rounded-xl text-xs text-amber-900 space-y-1">
                  <span className="font-bold block">Cash on Delivery Selected</span>
                  <p>
                    Please keep exact cash ready upon delivery. No upfront payment processing required.
                  </p>
                </div>
              )}

              <div className="pt-4 border-t border-slate-100 flex gap-3">
                <button
                  type="button"
                  onClick={() => setStep(3)}
                  disabled={isProcessing}
                  className="px-4 py-3 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold rounded-xl transition-colors"
                >
                  Back
                </button>
                <button
                  type="submit"
                  disabled={isProcessing}
                  className="flex-1 py-3.5 px-4 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold uppercase tracking-wider rounded-xl transition-colors flex items-center justify-center gap-2 shadow-md"
                >
                  {isProcessing ? (
                    <>
                      <Loader2 className="w-4 h-4 animate-spin" />
                      <span>Authorizing Payment...</span>
                    </>
                  ) : (
                    <>
                      <Lock className="w-4 h-4" />
                      <span>Pay ₹{checkoutSummary.grandTotal.toLocaleString('en-IN')}</span>
                    </>
                  )}
                </button>
              </div>
            </form>
          )}
        </div>

        {/* Right Column: Checkout Financial Summary */}
        <div className="lg:col-span-5 bg-white p-6 rounded-2xl border border-slate-200 shadow-xs space-y-4">
          <h3 className="text-xs font-bold uppercase tracking-wider text-slate-900 pb-3 border-b border-slate-100">
            Payment Breakdown
          </h3>

          <div className="space-y-2.5 text-xs">
            <div className="flex justify-between text-slate-600">
              <span>Merchandise Subtotal</span>
              <span className="font-mono font-semibold text-slate-900 tabular-nums">
                ₹{checkoutSummary.subtotal.toLocaleString('en-IN')}
              </span>
            </div>

            {checkoutSummary.discount > 0 && (
              <div className="flex justify-between text-emerald-600 font-medium">
                <span>Coupon Savings ({checkoutSummary.couponCode})</span>
                <span className="font-mono font-bold tabular-nums">
                  -₹{checkoutSummary.discount.toLocaleString('en-IN')}
                </span>
              </div>
            )}

            <div className="flex justify-between text-slate-600">
              <span>Shipping Fee</span>
              <span className="font-mono font-semibold text-slate-900 tabular-nums">
                {checkoutSummary.shipping === 0 ? (
                  <span className="text-emerald-600 font-bold">FREE</span>
                ) : (
                  `₹${checkoutSummary.shipping.toLocaleString('en-IN')}`
                )}
              </span>
            </div>

            <div className="flex justify-between text-slate-600">
              <span>Checkout Tax (18% GST)</span>
              <span className="font-mono font-semibold text-slate-900 tabular-nums">
                ₹{checkoutSummary.tax.toLocaleString('en-IN')}
              </span>
            </div>
          </div>

          <div className="pt-4 border-t border-slate-200 flex justify-between items-baseline">
            <div>
              <span className="text-sm font-bold text-slate-900">Total Payable</span>
              <span className="text-[11px] text-slate-400 block">Final charged balance</span>
            </div>
            <span className="text-2xl font-extrabold font-mono text-slate-900 tabular-nums">
              ₹{checkoutSummary.grandTotal.toLocaleString('en-IN')}
            </span>
          </div>

          {/* Discreet total mismatch indicator for testing agent */}
          {cartSummary.grandTotal !== checkoutSummary.grandTotal && (
            <div className="text-[11px] text-slate-400 font-mono pt-1">
              Cart Total was: ₹{cartSummary.grandTotal.toLocaleString('en-IN')} (Diff: ₹{Math.abs(cartSummary.grandTotal - checkoutSummary.grandTotal)})
            </div>
          )}

          <div className="pt-4 border-t border-slate-100 flex items-center gap-2 text-xs text-slate-500">
            <ShieldCheck className="w-4 h-4 text-emerald-600 shrink-0" />
            <span>256-Bit SSL Encrypted Mock Gateway</span>
          </div>
        </div>
      </div>
    </div>
  );
};
