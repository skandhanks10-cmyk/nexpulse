import React from 'react';
import { ArrowRight, Tag, Zap, Cpu, Sparkles, ChevronRight } from 'lucide-react';
import { productService } from '../services/productService';
import { ProductCard } from '../components/ProductCard';
import { ProductCategory } from '../types';

interface HomePageProps {
  onNavigate: (view: string, params?: any) => void;
  onSelectProduct: (productId: string) => void;
}

export const HomePage: React.FC<HomePageProps> = ({ onNavigate, onSelectProduct }) => {
  const featured = productService.getFeaturedProducts();
  const bestSellers = productService.getBestSellers().slice(0, 4);
  const discountDeals = productService.getDiscountDeals().slice(0, 4);

  const categoryCards: {
    category: ProductCategory;
    title: string;
    description: string;
    icon: string;
    count: number;
    bgGradient: string;
  }[] = [
    {
      category: 'Smartphones',
      title: 'Flagship Smartphones',
      description: 'Titanium chassis, 3nm neural chipsets, and pro optical zooms.',
      icon: '📱',
      count: 4,
      bgGradient: 'from-slate-900 to-indigo-950',
    },
    {
      category: 'Laptops',
      title: 'Pro Laptops & Ultrabooks',
      description: 'Silicon workstations, RTX graphics, and mini-LED displays.',
      icon: '💻',
      count: 4,
      bgGradient: 'from-slate-900 to-blue-950',
    },
    {
      category: 'Headphones',
      title: 'Spatial Audio & ANC',
      description: 'Hybrid noise-cancelling headphones and low-latency earbuds.',
      icon: '🎧',
      count: 4,
      bgGradient: 'from-slate-900 to-purple-950',
    },
    {
      category: 'Smartwatches',
      title: 'Wearables & Adventure',
      description: 'Dual-frequency GPS, sapphire glass, and ECG biosensors.',
      icon: '⌚',
      count: 4,
      bgGradient: 'from-slate-900 to-amber-950',
    },
    {
      category: 'Gaming',
      title: 'Esports Gaming Gear',
      description: 'Hall Effect controllers, 165Hz monitors, and mechanical boards.',
      icon: '🎮',
      count: 4,
      bgGradient: 'from-slate-900 to-rose-950',
    },
    {
      category: 'Accessories',
      title: 'Power & Fast GaN',
      description: '100W multi-chargers, braided 240W cables, and aluminum stands.',
      icon: '⚡',
      count: 4,
      bgGradient: 'from-slate-900 to-emerald-950',
    },
  ];

  return (
    <div className="space-y-16 pb-16">
      {/* 1. Storefront Hero Section */}
      <section className="relative overflow-hidden bg-slate-950 text-white border-b border-slate-800">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_80%_80%_at_50%_-20%,rgba(99,102,241,0.25),rgba(255,255,255,0))]" />
        
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20 lg:py-28 relative z-10">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
            {/* Left Content */}
            <div className="lg:col-span-7 space-y-6">
              <div className="inline-flex items-center gap-2 text-xs font-semibold text-indigo-400 bg-indigo-950/80 border border-indigo-800/60 px-3 py-1 rounded-md">
                <Sparkles className="w-3.5 h-3.5" />
                <span>2026 NEXT-GEN HARDWARE COLLECTION</span>
              </div>

              <h1 className="text-4xl sm:text-5xl lg:text-6xl font-extrabold tracking-tight text-white leading-tight">
                Engineered for Speed. <br />
                <span className="text-transparent bg-clip-text bg-gradient-to-r from-indigo-400 via-sky-300 to-teal-300">
                  Crafted for Precision.
                </span>
              </h1>

              <p className="text-base sm:text-lg text-slate-300 max-w-xl leading-relaxed">
                Experience cutting-edge smartphones, ultra-thin silicon notebooks, lossless studio acoustics, and competition gaming hardware with verified authentic warranties.
              </p>

              {/* CTAs */}
              <div className="flex flex-wrap items-center gap-4 pt-2">
                <button
                  onClick={() => onNavigate('products', { category: 'all' })}
                  className="px-6 py-3.5 text-sm font-bold text-slate-900 bg-white hover:bg-slate-100 rounded-lg shadow-lg hover:shadow-xl transition-all flex items-center gap-2"
                >
                  <span>Explore Catalog</span>
                  <ArrowRight className="w-4 h-4" />
                </button>

                <button
                  onClick={() => onNavigate('products', { category: 'Laptops' })}
                  className="px-6 py-3.5 text-sm font-semibold text-white bg-slate-800/90 hover:bg-slate-800 rounded-lg border border-slate-700 transition-colors"
                >
                  View Workstations
                </button>
              </div>

              {/* Trust Metric Strip */}
              <div className="pt-8 border-t border-slate-800/80 grid grid-cols-3 gap-6 text-left">
                <div>
                  <div className="text-xl sm:text-2xl font-bold font-mono text-white tabular-nums">24+</div>
                  <div className="text-xs text-slate-400 mt-0.5">Flagship Models</div>
                </div>
                <div>
                  <div className="text-xl sm:text-2xl font-bold font-mono text-white tabular-nums">₹3,000</div>
                  <div className="text-xs text-slate-400 mt-0.5">Free Shipping Cap</div>
                </div>
                <div>
                  <div className="text-xl sm:text-2xl font-bold font-mono text-white tabular-nums">100%</div>
                  <div className="text-xs text-slate-400 mt-0.5">Authentic Stock</div>
                </div>
              </div>
            </div>

            {/* Right Hero Showcase Card */}
            <div className="lg:col-span-5">
              <div className="relative rounded-2xl bg-gradient-to-b from-slate-900 to-slate-950 p-6 border border-slate-800 shadow-2xl">
                <div className="flex items-center justify-between text-xs text-slate-400 mb-4">
                  <span className="font-mono text-indigo-400 font-semibold">FEATURED SPOTLIGHT</span>
                  <span>IN STOCK</span>
                </div>

                <div className="relative aspect-4/3 rounded-xl overflow-hidden bg-slate-900 mb-5 border border-slate-800 flex items-center justify-center group cursor-pointer"
                  onClick={() => onSelectProduct('prod-laptop-1')}
                >
                  <img
                    src="https://images.unsplash.com/photo-1517336714731-489689fd1ca8?auto=format&fit=crop&w=800&q=80"
                    alt="NovaBook Pro 16 M3 Max"
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-slate-950/80 via-transparent to-transparent" />
                  <div className="absolute bottom-4 left-4 right-4">
                    <span className="text-xs font-semibold text-indigo-300">Nova Hardware</span>
                    <h3 className="text-base font-bold text-white">NovaBook Pro 16 M3 Max</h3>
                  </div>
                </div>

                <div className="flex items-center justify-between pt-2">
                  <div>
                    <div className="text-xs text-slate-400">Starting from</div>
                    <div className="text-xl font-bold text-white font-mono tabular-nums">
                      ₹1,49,999
                    </div>
                  </div>
                  <button
                    onClick={() => onSelectProduct('prod-laptop-1')}
                    className="px-4 py-2 text-xs font-bold text-white bg-indigo-600 hover:bg-indigo-500 rounded-lg transition-colors flex items-center gap-1.5"
                  >
                    <span>Configure</span>
                    <ChevronRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 2. Category Navigation Cards */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h2 className="text-2xl font-bold text-slate-900 tracking-tight">Browse by Category</h2>
            <p className="text-sm text-slate-500 mt-1">Explore our precision-tested tech departments</p>
          </div>
          <button
            onClick={() => onNavigate('products', { category: 'all' })}
            className="text-sm font-semibold text-indigo-600 hover:text-indigo-700 flex items-center gap-1"
          >
            <span>View All</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
          {categoryCards.map((cat) => (
            <button
              key={cat.category}
              onClick={() => onNavigate('products', { category: cat.category })}
              className="p-5 rounded-xl bg-white border border-slate-200 hover:border-indigo-300 hover:shadow-md transition-all text-left flex flex-col justify-between group"
            >
              <div className="text-3xl mb-3">{cat.icon}</div>
              <div>
                <h3 className="text-sm font-bold text-slate-900 group-hover:text-indigo-600 transition-colors">
                  {cat.category}
                </h3>
                <span className="text-xs text-slate-400 tabular-nums font-mono mt-0.5 block">
                  {cat.count} products
                </span>
              </div>
            </button>
          ))}
        </div>
      </section>

      {/* 3. Featured Flagship Products */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between mb-8">
          <div>
            <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-indigo-600 mb-1">
              <Zap className="w-3.5 h-3.5" />
              <span>Curated Selection</span>
            </div>
            <h2 className="text-2xl font-bold text-slate-900 tracking-tight">Featured Hardware</h2>
          </div>
          <button
            onClick={() => onNavigate('products', { category: 'all' })}
            className="text-sm font-semibold text-slate-700 hover:text-slate-900 flex items-center gap-1"
          >
            <span>Browse Full Catalog</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {featured.map((product) => (
            <ProductCard
              key={product.id}
              product={product}
              onSelect={onSelectProduct}
            />
          ))}
        </div>
      </section>

      {/* 4. Special Deals & Discounts Strip */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="rounded-2xl bg-gradient-to-r from-indigo-900 via-indigo-950 to-slate-950 p-8 sm:p-10 text-white relative overflow-hidden">
          <div className="relative z-10 flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
            <div className="space-y-2 max-w-xl">
              <div className="inline-flex items-center gap-1.5 text-xs font-bold text-indigo-300 bg-white/10 px-2.5 py-1 rounded">
                <Tag className="w-3.5 h-3.5" />
                <span>LIMITED TIME OFFER</span>
              </div>
              <h3 className="text-2xl sm:text-3xl font-extrabold tracking-tight">
                Save Up to 15% with Active Promo Codes
              </h3>
              <p className="text-sm text-slate-300">
                Apply coupon <span className="font-mono font-bold text-indigo-200">WELCOME15</span> for 15% off orders over ₹500, or <span className="font-mono font-bold text-indigo-200">SAVE10</span> for 10% instant checkout discount.
              </p>
            </div>

            <button
              onClick={() => onNavigate('products', { category: 'all' })}
              className="px-6 py-3 text-sm font-bold text-indigo-950 bg-white hover:bg-slate-100 rounded-lg shadow-md transition-colors shrink-0"
            >
              Shop Discounted Items
            </button>
          </div>
        </div>
      </section>

      {/* 5. Best Sellers Section */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between mb-8">
          <div>
            <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-amber-600 mb-1">
              <Cpu className="w-3.5 h-3.5" />
              <span>Community Favorites</span>
            </div>
            <h2 className="text-2xl font-bold text-slate-900 tracking-tight">Best Sellers</h2>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {bestSellers.map((product) => (
            <ProductCard
              key={product.id}
              product={product}
              onSelect={onSelectProduct}
            />
          ))}
        </div>
      </section>
    </div>
  );
};
