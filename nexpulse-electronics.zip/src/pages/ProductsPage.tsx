import React, { useState, useMemo } from 'react';
import { Search, SlidersHorizontal, RotateCcw, X } from 'lucide-react';
import { productService } from '../services/productService';
import { filterService, FilterOptions, SortOption } from '../services/filterService';
import { searchService } from '../services/searchService';
import { ProductCard } from '../components/ProductCard';

interface ProductsPageProps {
  initialCategory?: string;
  initialSearch?: string;
  onSelectProduct: (productId: string) => void;
}

export const ProductsPage: React.FC<ProductsPageProps> = ({
  initialCategory = 'all',
  initialSearch = '',
  onSelectProduct,
}) => {
  const allProducts = useMemo(() => productService.getAllProducts(), []);
  const allCategories = useMemo(() => productService.getCategories(), []);
  const allBrands = useMemo(() => productService.getBrands(), []);

  const [searchQuery, setSearchQuery] = useState(initialSearch);
  const [selectedCategory, setSelectedCategory] = useState<string>(initialCategory);
  const [selectedBrand, setSelectedBrand] = useState<string>('all');
  const [selectedPriceRange, setSelectedPriceRange] = useState<FilterOptions['priceRange']>('all');
  const [minRating, setMinRating] = useState<number>(0);
  const [inStockOnly, setInStockOnly] = useState<boolean>(false);
  const [sortBy, setSortBy] = useState<SortOption>('popularity');
  const [mobileFilterOpen, setMobileFilterOpen] = useState(false);

  // 1. Apply Search (Subject to BUG-04)
  const searchedProducts = useMemo(() => {
    return searchService.search(allProducts, searchQuery);
  }, [allProducts, searchQuery]);

  // 2. Apply Filters (Subject to BUG-05)
  const filteredProducts = useMemo(() => {
    const filterOptions: FilterOptions = {
      category: selectedCategory,
      brand: selectedBrand,
      priceRange: selectedPriceRange,
      minRating: minRating > 0 ? minRating : undefined,
      inStockOnly,
    };
    return filterService.filter(searchedProducts, filterOptions);
  }, [
    searchedProducts,
    selectedCategory,
    selectedBrand,
    selectedPriceRange,
    minRating,
    inStockOnly,
  ]);

  // 3. Apply Sorting
  const displayedProducts = useMemo(() => {
    return filterService.sort(filteredProducts, sortBy);
  }, [filteredProducts, sortBy]);

  const handleResetFilters = () => {
    setSelectedCategory('all');
    setSelectedBrand('all');
    setSelectedPriceRange('all');
    setMinRating(0);
    setInStockOnly(false);
    setSearchQuery('');
    setSortBy('popularity');
  };

  const hasActiveFilters =
    selectedCategory !== 'all' ||
    selectedBrand !== 'all' ||
    selectedPriceRange !== 'all' ||
    minRating > 0 ||
    inStockOnly ||
    searchQuery !== '';

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Header & Search */}
      <div className="mb-8">
        <h1 className="text-3xl font-extrabold text-slate-900 tracking-tight">
          Product Catalog
        </h1>
        <p className="text-sm text-slate-500 mt-1">
          Explore {allProducts.length} verified electronics devices, components, and accessories.
        </p>

        {/* Search Field */}
        <div className="mt-6 relative max-w-xl">
          <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search by product name, brand, or specs..."
            className="w-full pl-10 pr-10 py-2.5 text-sm bg-white border border-slate-200 rounded-lg text-slate-900 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-indigo-500 shadow-xs"
          />
          {searchQuery && (
            <button
              onClick={() => setSearchQuery('')}
              className="absolute right-3 top-1/2 -translate-y-1/2 p-1 text-slate-400 hover:text-slate-600"
            >
              <X className="w-4 h-4" />
            </button>
          )}
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-8 items-start">
        {/* Mobile Filter Toggle */}
        <div className="lg:hidden flex items-center justify-between pb-4 border-b border-slate-200">
          <button
            onClick={() => setMobileFilterOpen(!mobileFilterOpen)}
            className="flex items-center gap-2 px-4 py-2 text-xs font-semibold text-slate-700 bg-white border border-slate-200 rounded-lg"
          >
            <SlidersHorizontal className="w-4 h-4" />
            <span>Filters ({hasActiveFilters ? 'Active' : 'All'})</span>
          </button>

          <span className="text-xs text-slate-500">
            {displayedProducts.length} Products Found
          </span>
        </div>

        {/* Sidebar Filters */}
        <aside
          className={`lg:block ${
            mobileFilterOpen ? 'block' : 'hidden'
          } bg-white p-6 rounded-xl border border-slate-200 space-y-6 shadow-xs`}
        >
          <div className="flex items-center justify-between border-b border-slate-100 pb-4">
            <h2 className="text-sm font-bold uppercase tracking-wider text-slate-900">
              Filters
            </h2>
            {hasActiveFilters && (
              <button
                onClick={handleResetFilters}
                className="text-xs font-semibold text-indigo-600 hover:text-indigo-800 flex items-center gap-1"
              >
                <RotateCcw className="w-3 h-3" />
                <span>Reset</span>
              </button>
            )}
          </div>

          {/* Category Filter */}
          <div>
            <label className="text-xs font-bold uppercase tracking-wider text-slate-500 block mb-2">
              Category
            </label>
            <div className="space-y-1 text-sm">
              <button
                onClick={() => setSelectedCategory('all')}
                className={`w-full text-left px-2.5 py-1.5 rounded-md transition-colors ${
                  selectedCategory === 'all'
                    ? 'bg-slate-900 text-white font-semibold'
                    : 'text-slate-600 hover:bg-slate-100'
                }`}
              >
                All Categories
              </button>
              {allCategories.map((cat) => (
                <button
                  key={cat}
                  onClick={() => setSelectedCategory(cat)}
                  className={`w-full text-left px-2.5 py-1.5 rounded-md transition-colors ${
                    selectedCategory === cat
                      ? 'bg-slate-900 text-white font-semibold'
                      : 'text-slate-600 hover:bg-slate-100'
                  }`}
                >
                  {cat}
                </button>
              ))}
            </div>
          </div>

          {/* Brand Filter */}
          <div>
            <label className="text-xs font-bold uppercase tracking-wider text-slate-500 block mb-2">
              Brand
            </label>
            <select
              value={selectedBrand}
              onChange={(e) => setSelectedBrand(e.target.value)}
              className="w-full text-sm bg-slate-50 border border-slate-200 rounded-lg p-2 text-slate-800 focus:outline-none focus:ring-1 focus:ring-indigo-500"
            >
              <option value="all">All Brands</option>
              {allBrands.map((brand) => (
                <option key={brand} value={brand}>
                  {brand}
                </option>
              ))}
            </select>
          </div>

          {/* Price Range Filter (Triggers BUG-05) */}
          <div>
            <label className="text-xs font-bold uppercase tracking-wider text-slate-500 block mb-2">
              Price Range
            </label>
            <div className="space-y-1 text-sm">
              {[
                { id: 'all', label: 'All Prices' },
                { id: 'under-5000', label: 'Under ₹5,000' },
                { id: '5000-25000', label: '₹5,000 – ₹25,000' },
                { id: '25000-75000', label: '₹25,000 – ₹75,000' },
                { id: 'above-75000', label: 'Above ₹75,000' },
              ].map((p) => (
                <label
                  key={p.id}
                  className="flex items-center gap-2 text-slate-700 cursor-pointer py-1"
                >
                  <input
                    type="radio"
                    name="priceRange"
                    checked={selectedPriceRange === p.id}
                    onChange={() => setSelectedPriceRange(p.id as any)}
                    className="text-indigo-600 focus:ring-indigo-500 rounded-full"
                  />
                  <span>{p.label}</span>
                </label>
              ))}
            </div>
          </div>

          {/* Rating Filter */}
          <div>
            <label className="text-xs font-bold uppercase tracking-wider text-slate-500 block mb-2">
              Minimum Rating
            </label>
            <div className="space-y-1 text-sm">
              {[
                { val: 0, label: 'Any Rating' },
                { val: 4.0, label: '★ 4.0 & above' },
                { val: 4.5, label: '★ 4.5 & above' },
                { val: 4.8, label: '★ 4.8 & above' },
              ].map((r) => (
                <label
                  key={r.val}
                  className="flex items-center gap-2 text-slate-700 cursor-pointer py-1"
                >
                  <input
                    type="radio"
                    name="rating"
                    checked={minRating === r.val}
                    onChange={() => setMinRating(r.val)}
                    className="text-indigo-600 focus:ring-indigo-500 rounded-full"
                  />
                  <span>{r.label}</span>
                </label>
              ))}
            </div>
          </div>

          {/* In-stock Only */}
          <div className="pt-2 border-t border-slate-100">
            <label className="flex items-center gap-2 text-sm text-slate-800 cursor-pointer">
              <input
                type="checkbox"
                checked={inStockOnly}
                onChange={(e) => setInStockOnly(e.target.checked)}
                className="rounded text-indigo-600 focus:ring-indigo-500"
              />
              <span className="font-medium">In-Stock Only</span>
            </label>
          </div>
        </aside>

        {/* Product Grid Area */}
        <main className="lg:col-span-3">
          {/* Top Sort & Count Bar */}
          <div className="bg-white p-4 rounded-xl border border-slate-200 mb-6 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
            <div className="text-xs text-slate-500">
              Showing <span className="font-bold text-slate-900">{displayedProducts.length}</span> of {allProducts.length} products
              {searchQuery && (
                <span> for <span className="font-semibold text-indigo-600">"{searchQuery}"</span></span>
              )}
            </div>

            {/* Sorting Dropdown */}
            <div className="flex items-center gap-2 text-xs">
              <span className="text-slate-500 font-medium">Sort by:</span>
              <select
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value as SortOption)}
                className="bg-slate-50 border border-slate-200 rounded-lg px-2.5 py-1.5 text-slate-800 font-semibold focus:outline-none focus:ring-1 focus:ring-indigo-500"
              >
                <option value="popularity">Popularity (Most Reviews)</option>
                <option value="price-low-high">Price: Low to High</option>
                <option value="price-high-low">Price: High to Low</option>
                <option value="rating">Highest Rated</option>
                <option value="newest">Newest Arrivals</option>
              </select>
            </div>
          </div>

          {/* Product Cards */}
          {displayedProducts.length > 0 ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-6">
              {displayedProducts.map((product) => (
                <ProductCard
                  key={product.id}
                  product={product}
                  onSelect={onSelectProduct}
                />
              ))}
            </div>
          ) : (
            <div className="p-12 text-center bg-white rounded-xl border border-slate-200">
              <p className="text-base font-semibold text-slate-900 mb-1">
                No products match your criteria
              </p>
              <p className="text-xs text-slate-500 mb-6">
                Try adjusting your search terms, price boundaries, or clearing active filters.
              </p>
              <button
                onClick={handleResetFilters}
                className="px-4 py-2 text-xs font-semibold text-white bg-slate-900 hover:bg-slate-800 rounded-lg transition-colors"
              >
                Reset All Filters
              </button>
            </div>
          )}
        </main>
      </div>
    </div>
  );
};
