import React, { createContext, useContext, useEffect, useState, useMemo } from 'react';
import { CartItem, CartSummary, Product, ProductVariant } from '../types';
import { cartService, CartState } from '../services/cartService';
import { couponService } from '../services/couponService';

interface CartContextType {
  items: CartItem[];
  summary: CartSummary;
  couponCode?: string;
  residualOffset: number;
  addItem: (product: Product, selectedVariant?: ProductVariant, quantity?: number) => void;
  updateQuantity: (cartItemId: string, newQuantity: number) => void;
  removeItem: (cartItemId: string) => void;
  applyCoupon: (code: string) => { success: boolean; message: string };
  removeCoupon: () => void;
  clearCart: () => void;
  itemCount: number;
  lastAddedItem: CartItem | null;
  clearLastAddedNotification: () => void;
}

const CartContext = createContext<CartContextType | undefined>(undefined);

export const CartProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [cartState, setCartState] = useState<CartState>(() => {
    return cartService.loadFromStorage();
  });

  const [lastAddedItem, setLastAddedItem] = useState<CartItem | null>(null);

  // Sync to localStorage whenever cart state changes
  useEffect(() => {
    cartService.saveToStorage(cartState);
  }, [cartState]);

  // Compute live summary
  const summary = useMemo(() => {
    return cartService.calculateSummary(
      cartState.items,
      cartState.residualOffset,
      cartState.couponCode
    );
  }, [cartState.items, cartState.residualOffset, cartState.couponCode]);

  const addItem = (
    product: Product,
    selectedVariant?: ProductVariant,
    quantity: number = 1
  ) => {
    const newItem = cartService.createCartItem(product, selectedVariant, quantity);

    setCartState((prev) => {
      const existingIndex = prev.items.findIndex(
        (i) => i.cartItemId === newItem.cartItemId
      );

      let updatedItems: CartItem[];
      if (existingIndex > -1) {
        const existing = prev.items[existingIndex];
        const nextQty = existing.quantity + quantity;
        updatedItems = cartService.updateItemQuantity(prev.items, existing.cartItemId, nextQty);
      } else {
        updatedItems = [...prev.items, newItem];
      }

      return {
        ...prev,
        items: updatedItems,
      };
    });

    setLastAddedItem(newItem);
  };

  const updateQuantity = (cartItemId: string, newQuantity: number) => {
    setCartState((prev) => {
      const updatedItems = cartService.updateItemQuantity(
        prev.items,
        cartItemId,
        newQuantity
      );
      return {
        ...prev,
        items: updatedItems,
      };
    });
  };

  const removeItem = (cartItemId: string) => {
    setCartState((prev) => {
      const { nextItems, nextResidual } = cartService.removeItem(prev, cartItemId);
      return {
        ...prev,
        items: nextItems,
        residualOffset: nextResidual,
      };
    });
  };

  const applyCoupon = (code: string): { success: boolean; message: string } => {
    const itemsSum = cartState.items.reduce((s, i) => s + i.subtotal, 0) + cartState.residualOffset;
    const shipping = summary.shipping;

    const result = couponService.validateAndApply(code, itemsSum, cartState.items, shipping);

    if (result.isValid && result.coupon) {
      setCartState((prev) => ({
        ...prev,
        couponCode: result.coupon!.code,
      }));
      return { success: true, message: result.message };
    }

    return { success: false, message: result.message };
  };

  const removeCoupon = () => {
    setCartState((prev) => ({
      ...prev,
      couponCode: undefined,
    }));
  };

  const clearCart = () => {
    cartService.clearStorage();
    setCartState({
      items: [],
      residualOffset: 0,
      couponCode: undefined,
    });
  };

  const clearLastAddedNotification = () => {
    setLastAddedItem(null);
  };

  return (
    <CartContext.Provider
      value={{
        items: cartState.items,
        summary,
        couponCode: cartState.couponCode,
        residualOffset: cartState.residualOffset,
        addItem,
        updateQuantity,
        removeItem,
        applyCoupon,
        removeCoupon,
        clearCart,
        itemCount: summary.itemCount,
        lastAddedItem,
        clearLastAddedNotification,
      }}
    >
      {children}
    </CartContext.Provider>
  );
};

export const useCart = (): CartContextType => {
  const context = useContext(CartContext);
  if (!context) {
    throw new Error('useCart must be used within a CartProvider');
  }
  return context;
};
