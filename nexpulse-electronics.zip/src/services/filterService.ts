import { Product } from '../types';

export interface FilterOptions {
  category?: string;
  brand?: string;
  priceRange?: 'all' | 'under-5000' | '5000-25000' | '25000-75000' | 'above-75000';
  minRating?: number;
  inStockOnly?: boolean;
}

export type SortOption =
  | 'popularity'
  | 'price-low-high'
  | 'price-high-low'
  | 'rating'
  | 'newest';

export const filterService = {
  /**
   * Filters product list based on user criteria.
   *
   * INTENTIONAL DEFECT: BUG-05 (Filter Bug)
   * The price range filter evaluates `product.price` (the pre-discount MRP) rather than
   * `product.discountPrice` (the actual selling price).
   * Consequently:
   * - A product selling at ₹4,299 with an MRP of ₹5,499 is unexpectedly EXCLUDED from "Under ₹5,000".
   * - A product selling at ₹21,999 with an MRP of ₹25,999 is EXCLUDED from "₹5,000 - ₹25,000".
   */
  filter(products: Product[], filters: FilterOptions): Product[] {
    return products.filter((product) => {
      // Category filter
      if (filters.category && filters.category !== 'all' && product.category !== filters.category) {
        return false;
      }

      // Brand filter
      if (filters.brand && filters.brand !== 'all' && product.brand !== filters.brand) {
        return false;
      }

      // In-stock only filter
      if (filters.inStockOnly && !product.inStock) {
        return false;
      }

      // Rating filter
      if (filters.minRating && product.rating < filters.minRating) {
        return false;
      }

      // Price range filter - BUG-05: uses product.price (MRP) instead of product.discountPrice
      if (filters.priceRange && filters.priceRange !== 'all') {
        const targetPrice = product.price; // <-- DEFECT: Should be product.discountPrice

        switch (filters.priceRange) {
          case 'under-5000':
            if (targetPrice >= 5000) return false;
            break;
          case '5000-25000':
            if (targetPrice < 5000 || targetPrice > 25000) return false;
            break;
          case '25000-75000':
            if (targetPrice < 25000 || targetPrice > 75000) return false;
            break;
          case 'above-75000':
            if (targetPrice <= 75000) return false;
            break;
        }
      }

      return true;
    });
  },

  sort(products: Product[], sortBy: SortOption): Product[] {
    const sorted = [...products];

    switch (sortBy) {
      case 'price-low-high':
        return sorted.sort((a, b) => a.discountPrice - b.discountPrice);
      case 'price-high-low':
        return sorted.sort((a, b) => b.discountPrice - a.discountPrice);
      case 'rating':
        return sorted.sort((a, b) => b.rating - a.rating);
      case 'newest':
        return sorted.sort((a, b) => {
          const dateA = a.releaseDate ? new Date(a.releaseDate).getTime() : 0;
          const dateB = b.releaseDate ? new Date(b.releaseDate).getTime() : 0;
          return dateB - dateA;
        });
      case 'popularity':
      default:
        return sorted.sort((a, b) => b.reviewsCount - a.reviewsCount);
    }
  },
};
