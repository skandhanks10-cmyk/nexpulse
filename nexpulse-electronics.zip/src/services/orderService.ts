import { CartItem, CartSummary, CustomerInfo, Order, PaymentMethod, ShippingAddress } from '../types';

const ORDERS_STORAGE_KEY = 'nexpulse_orders_history';

export const orderService = {
  createOrder(params: {
    items: CartItem[];
    customerInfo: CustomerInfo;
    shippingAddress: ShippingAddress;
    paymentMethod: PaymentMethod;
    summary: CartSummary;
  }): Order {
    const randomSuffix = Math.floor(100000 + Math.random() * 900000);
    const orderId = `ORD-${randomSuffix}`;

    const newOrder: Order = {
      orderId,
      createdAt: new Date().toISOString(),
      items: [...params.items],
      customerInfo: { ...params.customerInfo },
      shippingAddress: { ...params.shippingAddress },
      paymentMethod: params.paymentMethod,
      summary: { ...params.summary },
      estimatedDelivery: '3–5 Business Days',
    };

    try {
      const existing = this.getAllOrders();
      localStorage.setItem(ORDERS_STORAGE_KEY, JSON.stringify([newOrder, ...existing]));
      localStorage.setItem('nexpulse_latest_order', JSON.stringify(newOrder));
    } catch {
      // Ignore
    }

    return newOrder;
  },

  getAllOrders(): Order[] {
    try {
      const raw = localStorage.getItem(ORDERS_STORAGE_KEY);
      return raw ? JSON.parse(raw) : [];
    } catch {
      return [];
    }
  },

  getLatestOrder(): Order | null {
    try {
      const raw = localStorage.getItem('nexpulse_latest_order');
      return raw ? JSON.parse(raw) : null;
    } catch {
      return null;
    }
  },

  getOrderById(orderId: string): Order | undefined {
    return this.getAllOrders().find((o) => o.orderId === orderId);
  },
};
