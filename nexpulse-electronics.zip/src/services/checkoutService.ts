import {
  CartSummary,
  CustomerInfo,
  PaymentDetails,
  ShippingAddress,
} from '../types';

export interface CheckoutValidationResult {
  isValid: boolean;
  errors: Record<string, string>;
}

export const checkoutService = {
  validateCustomerInfo(info: CustomerInfo): CheckoutValidationResult {
    const errors: Record<string, string> = {};

    if (!info.fullName.trim()) {
      errors.fullName = 'Full name is required';
    } else if (info.fullName.trim().length < 3) {
      errors.fullName = 'Full name must be at least 3 characters';
    }

    if (!info.email.trim()) {
      errors.email = 'Email address is required';
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(info.email.trim())) {
      errors.email = 'Please provide a valid email address';
    }

    if (!info.phone.trim()) {
      errors.phone = 'Phone number is required';
    } else if (!/^\d{10}$/.test(info.phone.trim().replace(/\D/g, ''))) {
      errors.phone = 'Please enter a valid 10-digit mobile number';
    }

    return {
      isValid: Object.keys(errors).length === 0,
      errors,
    };
  },

  /**
   * Validates shipping address fields.
   *
   * INTENTIONAL DEFECT: BUG-12 (Checkout Validation Bug)
   * The pincode validation check only checks length IF `address.pincode` is truthy:
   * `if (address.pincode && address.pincode.trim().length !== 6)`.
   * If the user leaves the postal pincode completely blank, no error is added to `errors`,
   * allowing the user to bypass the mandatory pincode requirement and proceed to payment!
   */
  validateShippingAddress(address: ShippingAddress): CheckoutValidationResult {
    const errors: Record<string, string> = {};

    if (!address.street.trim()) {
      errors.street = 'Street address / Flat number is required';
    }

    if (!address.city.trim()) {
      errors.city = 'City / District is required';
    }

    if (!address.state.trim()) {
      errors.state = 'State is required';
    }

    // DEFECT: BUG-12 Missing mandatory presence check for pincode
    if (address.pincode && address.pincode.trim().length !== 6) {
      errors.pincode = 'Pincode must be exactly 6 digits';
    }

    return {
      isValid: Object.keys(errors).length === 0,
      errors,
    };
  },

  validatePayment(payment: PaymentDetails): CheckoutValidationResult {
    const errors: Record<string, string> = {};

    if (payment.method === 'card') {
      const card = payment.cardDetails;
      if (!card?.cardNumber || card.cardNumber.replace(/\s/g, '').length !== 16) {
        errors.cardNumber = 'Enter a valid 16-digit card number';
      }
      if (!card?.expiry || !/^\d{2}\/\d{2}$/.test(card.expiry)) {
        errors.expiry = 'Enter expiry in MM/YY format';
      }
      if (!card?.cvv || card.cvv.length < 3) {
        errors.cvv = 'Enter 3 or 4 digit CVV';
      }
      if (!card?.cardHolder?.trim()) {
        errors.cardHolder = 'Cardholder name is required';
      }
    } else if (payment.method === 'upi') {
      if (!payment.upiId || !payment.upiId.includes('@')) {
        errors.upiId = 'Enter a valid UPI ID (e.g. name@okhdfcbank)';
      }
    }

    return {
      isValid: Object.keys(errors).length === 0,
      errors,
    };
  },

  /**
   * Calculates final checkout totals.
   *
   * INTENTIONAL DEFECT: BUG-10 (Checkout Total Mismatch)
   * On the Cart Page, tax is computed as `Math.round(subtotal * 0.18)` (before coupon discount).
   * Here on Checkout, the calculation recalculates tax as `Math.round((subtotal - discount) * 0.18)`.
   * Whenever a coupon discount is applied, the checkout grand total diverges from the cart total!
   */
  computeCheckoutSummary(baseSummary: CartSummary): CartSummary {
    const { subtotal, discount, couponCode, shipping, itemCount } = baseSummary;

    // DEFECT: BUG-10 Inconsistent tax formula between Cart and Checkout
    const checkoutTax = Math.round((subtotal - discount) * 0.18);
    const grandTotal = Math.max(0, subtotal - discount + shipping + checkoutTax);

    return {
      subtotal,
      discount,
      couponCode,
      shipping,
      tax: checkoutTax,
      grandTotal,
      itemCount,
    };
  },
};
