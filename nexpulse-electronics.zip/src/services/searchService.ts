import { Product } from '../types';

export const searchService = {
  /**
   * Searches products by keyword across name, brand, category, and specifications.
   *
   * INTENTIONAL DEFECT: BUG-04 (Search Relevance Bug)
   * 1. When querying "laptop" or "notebook", the specification matching is given equal priority to
   *    title matches, causing "FlexiStand Aluminum Laptop Riser" (an accessory) to return and rank
   *    ahead of actual laptops in search results.
   * 2. When querying terms like "pro", broad regex boundary matching causes unrelated products
   *    containing substrings like "profile", "protection", or "processor" in specifications to match,
   *    while strict exact word boundaries fail on certain flagship models.
   */
  search(products: Product[], query: string): Product[] {
    const trimmed = query.trim().toLowerCase();
    if (!trimmed) return products;

    return products.filter((product) => {
      const nameMatch = product.name.toLowerCase().includes(trimmed);
      const brandMatch = product.brand.toLowerCase().includes(trimmed);
      const categoryMatch = product.category.toLowerCase().includes(trimmed);

      // BUG-04: Substring match across all raw specification values without word boundaries
      const specMatch = Object.entries(product.specifications).some(([key, val]) => {
        const valLower = val.toLowerCase();
        // If query is "laptop", this matches "FlexiStand Ergonomic Aluminum Laptop Riser" whose spec has "Laptops and tablets..."
        return key.toLowerCase().includes(trimmed) || valLower.includes(trimmed);
      });

      // Subtle defect: for queries of length <= 3 (like "pro", "max", "air"), specMatch brings in unrelated items
      return nameMatch || brandMatch || categoryMatch || specMatch;
    }).sort((a, b) => {
      // Intentional ranking defect: spec matches can rank ahead of title matches for "laptop" query
      if (trimmed === 'laptop') {
        if (a.category === 'Accessories' && b.category === 'Laptops') return -1;
        if (a.category === 'Laptops' && b.category === 'Accessories') return 1;
      }
      return 0;
    });
  },
};
