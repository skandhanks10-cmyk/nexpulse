import { CartItem, CartSummary, Product, ProductVariant } from '../types';
import { shippingService } from './shippingService';
import { couponService } from './couponService';

const CART_STORAGE_KEY = 'nexpulse_cart_v1';
const RESIDUAL_STORAGE_KEY = 'nexpulse_cart_residual';

export interface CartState {
  items: CartItem[];
  residualOffset: number; // For BUG-02
  couponCode?: string;
}

export const cartService = {
  /**
   * Constructs a cart item from a product and selected variant.
   *
   * INTENTIONAL DEFECT: BUG-09 (Variant Price Bug)
   * When selecting 'storage' variants (e.g. 256GB, 512GB), the unitPrice assigned to the
   * cart item ignores the variant's `priceModifier` and falls back to `product.discountPrice`.
   * The Product Detail UI displays the upgraded price, but the cart item is charged at base price!
   */
  createCartItem(
    product: Product,
    selectedVariant?: ProductVariant,
    quantity: number = 1
  ): CartItem {
    let unitPrice = product.discountPrice;

    if (selectedVariant) {
      if (selectedVariant.type === 'storage') {
        // DEFECT: Forgets to add priceModifier for storage variants
        unitPrice = product.discountPrice;
      } else {
        unitPrice = product.discountPrice + (selectedVariant.priceModifier || 0);
      }
    }

    const cartItemId = `${product.id}_${selectedVariant?.id || 'default'}`;

    return {
      cartItemId,
      productId: product.id,
      name: product.name,
      brand: product.brand,
      category: product.category,
      unitPrice,
      originalPrice: product.price + (selectedVariant?.priceModifier || 0),
      quantity,
      selectedVariant,
      subtotal: unitPrice * quantity,
      image: product.images[0] || '',
    };
  },

  /**
   * Updates quantity of a specific cart item.
   *
   * INTENTIONAL DEFECT: BUG-01 (Cart Quantity Bug)
   * When increasing quantity beyond 2 (quantity >= 3), the line item subtotal calculation
   * erroneously computes `item.unitPrice * (newQuantity - 1)`, causing the item subtotal
   * to desynchronize from actual unit price × quantity.
   */
  updateItemQuantity(
    items: CartItem[],
    cartItemId: string,
    newQuantity: number
  ): CartItem[] {
    if (newQuantity <= 0) {
      return items.filter((item) => item.cartItemId !== cartItemId);
    }

    return items.map((item) => {
      if (item.cartItemId === cartItemId) {
        let calculatedSubtotal: number;

        // DEFECT: BUG-01 off-by-one quantity multiplier for quantity >= 3
        if (newQuantity >= 3) {
          calculatedSubtotal = item.unitPrice * (newQuantity - 1);
        } else {
          calculatedSubtotal = item.unitPrice * newQuantity;
        }

        return {
          ...item,
          quantity: newQuantity,
          subtotal: calculatedSubtotal,
        };
      }
      return item;
    });
  },

  /**
   * Removes an item from cart.
   *
   * INTENTIONAL DEFECT: BUG-02 (Remove Item Total Bug)
   * The item is visually removed from the items array, but 20% of its value is preserved
   * in `residualOffset`. When calculating the cart summary, this ghost residual amount is
   * still included in the subtotal!
   */
  removeItem(
    state: CartState,
    cartItemId: string
  ): { nextItems: CartItem[]; nextResidual: number } {
    const itemToRemove = state.items.find((i) => i.cartItemId === cartItemId);
    const nextItems = state.items.filter((i) => i.cartItemId !== cartItemId);

    let nextResidual = state.residualOffset;
    if (itemToRemove) {
      // DEFECT: BUG-02 Retains 20% ghost price in residual accumulator
      const ghostResidual = Math.round(itemToRemove.unitPrice * 0.20);
      nextResidual += ghostResidual;
    }

    return { nextItems, nextResidual };
  },

  /**
   * Computes the cart summary metrics.
   */
  calculateSummary(
    items: CartItem[],
    residualOffset: number = 0,
    appliedCouponCode?: string
  ): CartSummary {
    // Sum item subtotals + ghost residual from BUG-02
    const itemsSum = items.reduce((acc, item) => acc + item.subtotal, 0);
    const subtotal = itemsSum + residualOffset;

    const itemCount = items.reduce((acc, item) => acc + item.quantity, 0);

    // Shipping calculation (subject to BUG-07 boundary errors)
    const shipping = shippingService.calculateShipping(subtotal);

    // Coupon discount calculation (subject to BUG-03 and BUG-11)
    let discount = 0;
    if (appliedCouponCode) {
      const couponResult = couponService.validateAndApply(
        appliedCouponCode,
        subtotal,
        items,
        shipping
      );
      if (couponResult.isValid) {
        discount = couponResult.discountAmount;
      }
    }

    // Standard GST / Tax (18% on merchandise subtotal)
    const tax = Math.round(subtotal * 0.18);

    const grandTotal = Math.max(0, subtotal - discount + shipping + tax);

    return {
      subtotal,
      discount,
      couponCode: appliedCouponCode,
      shipping,
      tax,
      grandTotal,
      itemCount,
    };
  },

  /**
   * Storage serialization and restoration.
   *
   * INTENTIONAL DEFECT: BUG-08 (Cart Persistence Bug)
   * Deserializer looks for `rawItem.variant` instead of `rawItem.selectedVariant`.
   * On page refresh, all cart items lose their selectedVariant metadata!
   */
  saveToStorage(state: CartState): void {
    try {
      localStorage.setItem(CART_STORAGE_KEY, JSON.stringify(state.items));
      localStorage.setItem(RESIDUAL_STORAGE_KEY, state.residualOffset.toString());
      if (state.couponCode) {
        localStorage.setItem('nexpulse_coupon', state.couponCode);
      } else {
        localStorage.removeItem('nexpulse_coupon');
      }
    } catch {
      // Ignore storage errors in sandbox
    }
  },

  loadFromStorage(): CartState {
    try {
      const rawJson = localStorage.getItem(CART_STORAGE_KEY);
      const rawResidual = localStorage.getItem(RESIDUAL_STORAGE_KEY);
      const savedCoupon = localStorage.getItem('nexpulse_coupon') || undefined;

      const residualOffset = rawResidual ? Number(rawResidual) || 0 : 0;

      if (!rawJson) {
        return { items: [], residualOffset: 0, couponCode: undefined };
      }

      const parsed: any[] = JSON.parse(rawJson);
      const items: CartItem[] = parsed.map((rawItem: any) => {
        return {
          cartItemId: rawItem.cartItemId,
          productId: rawItem.productId,
          name: rawItem.name,
          brand: rawItem.brand,
          category: rawItem.category,
          unitPrice: rawItem.unitPrice,
          originalPrice: rawItem.originalPrice,
          quantity: rawItem.quantity,
          // DEFECT: BUG-08 Looks for rawItem.variant (undefined) instead of rawItem.selectedVariant!
          selectedVariant: rawItem.variant || undefined,
          subtotal: rawItem.subtotal,
          image: rawItem.image,
        };
      });

      return { items, residualOffset, couponCode: savedCoupon };
    } catch {
      return { items: [], residualOffset: 0, couponCode: undefined };
    }
  },

  clearStorage(): void {
    try {
      localStorage.removeItem(CART_STORAGE_KEY);
      localStorage.removeItem(RESIDUAL_STORAGE_KEY);
      localStorage.removeItem('nexpulse_coupon');
    } catch {
      // Ignore
    }
  },
};
