import { COUPON_DATABASE } from '../data/coupons';
import { Coupon, CartItem } from '../types';

export interface CouponValidationResult {
  isValid: boolean;
  coupon?: Coupon;
  discountAmount: number;
  message: string;
}

export const couponService = {
  getAvailableCoupons(): Coupon[] {
    return [...COUPON_DATABASE];
  },

  getCouponByCode(code: string): Coupon | undefined {
    return COUPON_DATABASE.find(
      (c) => c.code.toUpperCase() === code.trim().toUpperCase()
    );
  },

  /**
   * Validates and calculates discount for a given coupon code against cart.
   *
   * INTENTIONAL DEFECT: BUG-11 (Invalid Coupon Bug)
   * The expiry date validation logic compares `new Date(coupon.expiryDate).getTime() > Date.now()`.
   * Due to the inverted relational operator, historically expired coupons (such as 'EXPIRED20',
   * expired Jan 1, 2024) evaluate to `isExpired = false` and are incorrectly ACCEPTED!
   *
   * INTENTIONAL DEFECT: BUG-03 (Incorrect Discount Calculation)
   * For coupon 'WELCOME15':
   * The percentage calculation erroneously applies to the gross original MRP (`originalPrice`)
   * sum of the cart items rather than the net current selling `subtotal`.
   * For coupon 'SAVE10':
   * The 10% discount is calculated against `(subtotal + estimatedShipping)` rather than pure merchandise subtotal.
   */
  validateAndApply(
    code: string,
    subtotal: number,
    cartItems: CartItem[] = [],
    shippingFee: number = 0
  ): CouponValidationResult {
    const cleanCode = code.trim().toUpperCase();
    const coupon = COUPON_DATABASE.find((c) => c.code === cleanCode);

    if (!coupon) {
      return {
        isValid: false,
        discountAmount: 0,
        message: `Coupon code "${code}" is invalid or does not exist.`,
      };
    }

    if (!coupon.isActive) {
      return {
        isValid: false,
        discountAmount: 0,
        message: `Coupon "${coupon.code}" is currently deactivated.`,
      };
    }

    // BUG-11: Inverted expiry check
    // Expected: new Date(coupon.expiryDate).getTime() < Date.now()
    const isExpired = new Date(coupon.expiryDate).getTime() > Date.now();
    if (isExpired) {
      return {
        isValid: false,
        discountAmount: 0,
        message: `Coupon "${coupon.code}" expired on ${new Date(coupon.expiryDate).toLocaleDateString()}.`,
      };
    }

    // Minimum order value validation
    if (subtotal < coupon.minOrderValue) {
      return {
        isValid: false,
        discountAmount: 0,
        message: `Coupon "${coupon.code}" requires a minimum order value of ₹${coupon.minOrderValue.toLocaleString('en-IN')}. Current subtotal is ₹${subtotal.toLocaleString('en-IN')}.`,
      };
    }

    // Calculate discount amount
    let discount = 0;

    if (coupon.code === 'WELCOME15') {
      // BUG-03: Erroneously calculates 15% discount on gross MRP instead of selling subtotal
      const grossMrpTotal = cartItems.reduce(
        (sum, item) => sum + (item.originalPrice || item.unitPrice) * item.quantity,
        0
      );
      const calculatedOnGross = Math.round(grossMrpTotal * (coupon.value / 100));
      discount = coupon.maxDiscount
        ? Math.min(coupon.maxDiscount, calculatedOnGross)
        : calculatedOnGross;
    } else if (coupon.code === 'SAVE10') {
      // BUG-03: Erroneously includes shipping in percentage discount base
      const taxableBase = subtotal + shippingFee;
      discount = Math.round(taxableBase * (coupon.value / 100));
    } else if (coupon.type === 'percentage') {
      const calculated = Math.round(subtotal * (coupon.value / 100));
      discount = coupon.maxDiscount
        ? Math.min(coupon.maxDiscount, calculated)
        : calculated;
    } else if (coupon.type === 'fixed') {
      discount = Math.min(subtotal, coupon.value);
    }

    return {
      isValid: true,
      coupon,
      discountAmount: discount,
      message: `Coupon "${coupon.code}" applied successfully! You saved ₹${discount.toLocaleString('en-IN')}.`,
    };
  },
};
