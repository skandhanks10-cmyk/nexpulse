export const shippingService = {
  /**
   * Calculates shipping cost based on cart subtotal value.
   *
   * Business Rules:
   * - ₹0 – ₹999        → ₹99 shipping
   * - ₹1,000 – ₹2,999  → ₹59 shipping
   * - ₹3,000+          → FREE (₹0)
   *
   * INTENTIONAL DEFECT: BUG-07 (Shipping Calculation Bug)
   * Boundary condition defect:
   * - At exactly ₹1,000: Condition `subtotal <= 1000` evaluates to true, charging ₹99 instead of ₹59.
   * - At exactly ₹3,000: Condition `subtotal <= 3000` evaluates to true, charging ₹59 instead of ₹0 (FREE).
   */
  calculateShipping(cartSubtotal: number): number {
    if (cartSubtotal === 0) return 0;

    // DEFECT: Boundary checks include 1000 in highest tier and 3000 in intermediate tier
    if (cartSubtotal <= 1000) {
      return 99;
    } else if (cartSubtotal <= 3000) {
      return 59;
    } else {
      return 0;
    }
  },

  getFreeShippingThreshold(): number {
    return 3000;
  },

  getShippingStatusMessage(cartSubtotal: number): { message: string; progress: number; isFree: boolean } {
    const threshold = 3000;
    if (cartSubtotal >= threshold) {
      return {
        message: 'Your order qualifies for FREE Express Delivery!',
        progress: 100,
        isFree: true,
      };
    }
    const needed = threshold - cartSubtotal;
    const progress = Math.min(100, Math.round((cartSubtotal / threshold) * 100));
    return {
      message: `Add ₹${needed.toLocaleString('en-IN')} more to unlock FREE Delivery`,
      progress,
      isFree: false,
    };
  },
};
