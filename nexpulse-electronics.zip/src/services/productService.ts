import { SAMPLE_PRODUCTS } from '../data/products';
import { Product, ProductCategory } from '../types';

export const productService = {
  getAllProducts(): Product[] {
    return [...SAMPLE_PRODUCTS];
  },

  getProductById(id: string): Product | undefined {
    return SAMPLE_PRODUCTS.find((p) => p.id === id);
  },

  getFeaturedProducts(): Product[] {
    return SAMPLE_PRODUCTS.filter((p) => p.isFeatured);
  },

  getBestSellers(): Product[] {
    return SAMPLE_PRODUCTS.filter((p) => p.isBestSeller);
  },

  getDiscountDeals(): Product[] {
    return SAMPLE_PRODUCTS.filter((p) => {
      const discountPercent = Math.round(((p.price - p.discountPrice) / p.price) * 100);
      return discountPercent >= 15;
    });
  },

  getCategories(): ProductCategory[] {
    return [
      'Smartphones',
      'Laptops',
      'Headphones',
      'Smartwatches',
      'Gaming',
      'Accessories',
    ];
  },

  getBrands(): string[] {
    const brands = new Set(SAMPLE_PRODUCTS.map((p) => p.brand));
    return Array.from(brands).sort();
  },
};
