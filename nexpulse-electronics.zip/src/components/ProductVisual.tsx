import React, { useState } from 'react';
import { Smartphone, Laptop, Headphones, Watch, Gamepad2, Cable } from 'lucide-react';
import { ProductCategory } from '../types';

interface ProductVisualProps {
  imageSrc?: string;
  name: string;
  category: ProductCategory;
  gradient?: string;
  className?: string;
  aspectRatio?: 'square' | 'wide' | 'portrait';
}

export const ProductVisual: React.FC<ProductVisualProps> = ({
  imageSrc,
  name,
  category,
  gradient = 'from-slate-900 to-slate-950',
  className = '',
  aspectRatio = 'square',
}) => {
  const [imgError, setImgError] = useState(false);

  const getCategoryIcon = () => {
    switch (category) {
      case 'Smartphones':
        return <Smartphone className="w-12 h-12 text-slate-300 stroke-[1.5]" />;
      case 'Laptops':
        return <Laptop className="w-14 h-14 text-slate-300 stroke-[1.5]" />;
      case 'Headphones':
        return <Headphones className="w-12 h-12 text-slate-300 stroke-[1.5]" />;
      case 'Smartwatches':
        return <Watch className="w-12 h-12 text-slate-300 stroke-[1.5]" />;
      case 'Gaming':
        return <Gamepad2 className="w-12 h-12 text-slate-300 stroke-[1.5]" />;
      case 'Accessories':
      default:
        return <Cable className="w-12 h-12 text-slate-300 stroke-[1.5]" />;
    }
  };

  const aspectClass =
    aspectRatio === 'wide'
      ? 'aspect-video'
      : aspectRatio === 'portrait'
      ? 'aspect-[3/4]'
      : 'aspect-square';

  return (
    <div
      className={`relative overflow-hidden bg-slate-900 rounded-lg flex items-center justify-center ${aspectClass} ${className}`}
    >
      {imageSrc && !imgError ? (
        <img
          src={imageSrc}
          alt={name}
          referrerPolicy="no-referrer"
          onError={() => setImgError(true)}
          className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
        />
      ) : (
        /* Styled resilient fallback container */
        <div
          className={`w-full h-full bg-gradient-to-br ${gradient} flex flex-col items-center justify-center p-6 text-center select-none`}
        >
          <div className="p-4 rounded-xl bg-white/5 border border-white/10 mb-3 shadow-inner">
            {getCategoryIcon()}
          </div>
          <span className="text-xs font-semibold uppercase tracking-wider text-slate-400">
            {category}
          </span>
          <span className="text-xs font-medium text-slate-200 line-clamp-1 mt-1 max-w-[85%]">
            {name}
          </span>
        </div>
      )}
    </div>
  );
};
