import React, { useState } from 'react';
import { ShoppingBag, Search, X, ShieldCheck } from 'lucide-react';
import { useCart } from '../context/CartContext';
import { ProductCategory } from '../types';

interface NavbarProps {
  currentView: string;
  onNavigate: (view: string, params?: any) => void;
  onSearchSubmit?: (query: string) => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentView,
  onNavigate,
  onSearchSubmit,
}) => {
  const { itemCount } = useCart();
  const [searchOpen, setSearchOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (onSearchSubmit) {
      onSearchSubmit(searchQuery);
    }
    onNavigate('products', { search: searchQuery });
  };

  const navCategories: { label: string; category?: ProductCategory | 'all' }[] = [
    { label: 'Catalog', category: 'all' },
    { label: 'Smartphones', category: 'Smartphones' },
    { label: 'Laptops', category: 'Laptops' },
    { label: 'Audio', category: 'Headphones' },
    { label: 'Gaming', category: 'Gaming' },
  ];

  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-slate-200">
      {/* Top Bar Announcement / Trust Strip */}
      <div className="bg-slate-900 text-slate-300 text-xs py-1.5 px-4 text-center font-medium">
        <span>⚡ Free Express Delivery on all orders above ₹3,000 · Use coupon </span>
        <button
          onClick={() => {
            navigator.clipboard?.writeText('SAVE10');
            alert?.('Copied SAVE10 to clipboard');
          }}
          className="text-indigo-400 font-semibold underline underline-offset-2 hover:text-indigo-300 ml-1"
        >
          SAVE10
        </button>
      </div>

      {/* Main Top Bar Contract */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between gap-8 h-16">
          {/* Zone 1: Single text element Brand Wordmark */}
          <button
            onClick={() => onNavigate('home')}
            className="text-xl font-extrabold tracking-tight text-slate-900 whitespace-nowrap shrink-0 hover:opacity-90 transition-opacity flex items-center gap-2"
          >
            <span>NexPulse</span>
            <span className="text-xs font-semibold px-1.5 py-0.5 rounded bg-slate-100 text-slate-700 tracking-normal font-mono">
              TECH
            </span>
          </button>

          {/* Zone 2: 4-5 single-line nav links */}
          <nav className="hidden md:flex items-center gap-6 text-sm font-medium text-slate-600">
            {navCategories.map((item) => (
              <button
                key={item.label}
                onClick={() => onNavigate('products', { category: item.category })}
                className={`hover:text-slate-900 transition-colors whitespace-nowrap shrink-0 py-1 ${
                  currentView === 'products' ? 'text-slate-900' : ''
                }`}
              >
                {item.label}
              </button>
            ))}
          </nav>

          {/* Zone 3: Search & Primary Action (Cart) */}
          <div className="flex items-center gap-3 shrink-0">
            {/* Search Toggle Button */}
            <button
              onClick={() => setSearchOpen(!searchOpen)}
              className="p-2 text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded-lg transition-colors"
              aria-label="Search products"
            >
              <Search className="w-5 h-5" />
            </button>

            {/* QA Testing Route Button */}
            <button
              onClick={() => onNavigate('qa')}
              title="Open QA Testing & Defect Inspection Suite"
              className="hidden lg:flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-semibold text-amber-700 bg-amber-50 hover:bg-amber-100 rounded-md border border-amber-200 transition-colors"
            >
              <ShieldCheck className="w-3.5 h-3.5" />
              <span>QA Suite</span>
            </button>

            {/* Primary Action: Cart */}
            <button
              onClick={() => onNavigate('cart')}
              className="relative flex items-center gap-2 px-4 py-2 text-sm font-semibold text-white bg-slate-900 hover:bg-slate-800 rounded-lg transition-colors whitespace-nowrap shrink-0 shadow-sm"
              aria-label="Shopping Cart"
            >
              <ShoppingBag className="w-4 h-4" />
              <span className="hidden sm:inline">Cart</span>
              {itemCount > 0 && (
                <span className="tabular-nums font-mono text-xs bg-indigo-500 text-white font-bold px-1.5 py-0.2 rounded-full min-w-5 text-center">
                  {itemCount}
                </span>
              )}
            </button>
          </div>
        </div>

        {/* Collapsible Search Input Bar */}
        {searchOpen && (
          <div className="pb-4 pt-1">
            <form onSubmit={handleSearchSubmit} className="relative flex items-center">
              <Search className="absolute left-3.5 w-4 h-4 text-slate-400" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search products by model, brand, or specs (e.g. 'Pro', 'Titanium', 'OLED')..."
                className="w-full pl-10 pr-10 py-2.5 text-sm bg-slate-100 border border-slate-200 rounded-lg text-slate-900 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:bg-white transition-all"
                autoFocus
              />
              <button
                type="button"
                onClick={() => setSearchOpen(false)}
                className="absolute right-3 p-1 text-slate-400 hover:text-slate-600"
              >
                <X className="w-4 h-4" />
              </button>
            </form>
          </div>
        )}
      </div>
    </header>
  );
};
