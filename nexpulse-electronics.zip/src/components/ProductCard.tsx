import React from 'react';
import { Star, ShoppingBag, ArrowRight } from 'lucide-react';
import { Product } from '../types';
import { ProductVisual } from './ProductVisual';
import { useCart } from '../context/CartContext';

interface ProductCardProps {
  product: Product;
  onSelect: (productId: string) => void;
}

export const ProductCard: React.FC<ProductCardProps> = ({ product, onSelect }) => {
  const { addItem } = useCart();

  const discountPercent = Math.round(
    ((product.price - product.discountPrice) / product.price) * 100
  );

  const handleQuickAdd = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (!product.inStock) return;
    const defaultVariant = product.variants[0];
    addItem(product, defaultVariant, 1);
  };

  return (
    <div
      onClick={() => onSelect(product.id)}
      className="group bg-white rounded-xl border border-slate-200 overflow-hidden hover:shadow-lg transition-all duration-200 flex flex-col cursor-pointer relative"
    >
      {/* Visual Area */}
      <div className="relative p-3 bg-slate-50">
        <ProductVisual
          imageSrc={product.images[0]}
          name={product.name}
          category={product.category}
          gradient={product.thumbnailGradient}
          aspectRatio="square"
          className="rounded-lg"
        />

        {/* Quiet Discount Tag (No pill cliche) */}
        {discountPercent > 0 && (
          <span className="absolute top-5 left-5 text-xs font-bold text-emerald-800 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
            {discountPercent}% OFF
          </span>
        )}

        {!product.inStock && (
          <div className="absolute inset-0 bg-slate-900/60 backdrop-blur-[2px] flex items-center justify-center rounded-xl m-3">
            <span className="text-xs font-bold uppercase tracking-wider text-white bg-rose-600 px-3 py-1 rounded">
              Out of Stock
            </span>
          </div>
        )}
      </div>

      {/* Details Area */}
      <div className="p-4 flex flex-col flex-1">
        {/* Brand & Category */}
        <div className="flex items-center justify-between text-xs text-slate-500 mb-1.5">
          <span className="font-semibold uppercase tracking-wider text-slate-400">
            {product.brand}
          </span>
          <div className="flex items-center gap-1 text-amber-500 font-medium">
            <Star className="w-3.5 h-3.5 fill-current" />
            <span className="text-slate-700 tabular-nums">{product.rating}</span>
            <span className="text-slate-400">({product.reviewsCount})</span>
          </div>
        </div>

        {/* Product Title */}
        <h3 className="text-sm font-bold text-slate-900 group-hover:text-indigo-600 transition-colors line-clamp-1 mb-2">
          {product.name}
        </h3>

        {/* Short Specs Sneak Peek */}
        <p className="text-xs text-slate-500 line-clamp-2 mb-4 flex-1">
          {product.description}
        </p>

        {/* Price Row */}
        <div className="pt-2 border-t border-slate-100 flex items-baseline justify-between mb-4">
          <div className="flex items-baseline gap-2">
            <span className="text-lg font-bold text-slate-900 tabular-nums font-mono">
              ₹{product.discountPrice.toLocaleString('en-IN')}
            </span>
            {product.price > product.discountPrice && (
              <span className="text-xs text-slate-400 line-through tabular-nums font-mono">
                ₹{product.price.toLocaleString('en-IN')}
              </span>
            )}
          </div>
          <span className="text-xs text-slate-500">
            {product.inStock ? (
              <span className="text-emerald-600 font-medium">In Stock</span>
            ) : (
              <span className="text-rose-500 font-medium">Sold Out</span>
            )}
          </span>
        </div>

        {/* Actions */}
        <div className="grid grid-cols-2 gap-2 mt-auto">
          <button
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              onSelect(product.id);
            }}
            className="flex items-center justify-center gap-1 px-3 py-2 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors"
          >
            <span>Details</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>

          <button
            type="button"
            onClick={handleQuickAdd}
            disabled={!product.inStock}
            className={`flex items-center justify-center gap-1 px-3 py-2 text-xs font-semibold rounded-lg transition-colors shadow-xs ${
              product.inStock
                ? 'bg-slate-900 hover:bg-slate-800 text-white'
                : 'bg-slate-200 text-slate-400 cursor-not-allowed'
            }`}
          >
            <ShoppingBag className="w-3.5 h-3.5" />
            <span>Add</span>
          </button>
        </div>
      </div>
    </div>
  );
};
