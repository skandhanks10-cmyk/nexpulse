import React from 'react';
import { Truck, Shield, RotateCcw, Award } from 'lucide-react';

interface FooterProps {
  onNavigate: (view: string, params?: any) => void;
}

export const Footer: React.FC<FooterProps> = ({ onNavigate }) => {
  return (
    <footer className="bg-slate-900 text-slate-300 border-t border-slate-800 mt-20">
      {/* Trust & Guarantee Strip */}
      <div className="border-b border-slate-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div className="flex items-start gap-4">
              <div className="p-2.5 rounded-lg bg-slate-800 text-indigo-400 shrink-0">
                <Truck className="w-6 h-6" />
              </div>
              <div>
                <h4 className="text-sm font-semibold text-white">Free Express Shipping</h4>
                <p className="text-xs text-slate-400 mt-1">Automatic waiver on orders over ₹3,000</p>
              </div>
            </div>

            <div className="flex items-start gap-4">
              <div className="p-2.5 rounded-lg bg-slate-800 text-indigo-400 shrink-0">
                <Shield className="w-6 h-6" />
              </div>
              <div>
                <h4 className="text-sm font-semibold text-white">1-Year Official Warranty</h4>
                <p className="text-xs text-slate-400 mt-1">Direct brand service center support</p>
              </div>
            </div>

            <div className="flex items-start gap-4">
              <div className="p-2.5 rounded-lg bg-slate-800 text-indigo-400 shrink-0">
                <RotateCcw className="w-6 h-6" />
              </div>
              <div>
                <h4 className="text-sm font-semibold text-white">7-Day Replacement</h4>
                <p className="text-xs text-slate-400 mt-1">Hassle-free hardware replacement policy</p>
              </div>
            </div>

            <div className="flex items-start gap-4">
              <div className="p-2.5 rounded-lg bg-slate-800 text-indigo-400 shrink-0">
                <Award className="w-6 h-6" />
              </div>
              <div>
                <h4 className="text-sm font-semibold text-white">100% Authentic Tech</h4>
                <p className="text-xs text-slate-400 mt-1">Directly sourced and sealed inventory</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Main Footer Links */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
          <div>
            <span className="text-lg font-bold text-white tracking-tight">NexPulse</span>
            <p className="text-xs text-slate-400 mt-3 leading-relaxed">
              Curated consumer electronics, pro workstations, and high-performance gaming gear built for professionals and enthusiasts.
            </p>
          </div>

          <div>
            <h5 className="text-xs font-semibold uppercase tracking-wider text-slate-400 mb-4">
              Categories
            </h5>
            <ul className="space-y-2 text-sm">
              <li>
                <button
                  onClick={() => onNavigate('products', { category: 'Smartphones' })}
                  className="hover:text-white transition-colors"
                >
                  Smartphones
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('products', { category: 'Laptops' })}
                  className="hover:text-white transition-colors"
                >
                  Laptops & Workstations
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('products', { category: 'Headphones' })}
                  className="hover:text-white transition-colors"
                >
                  Audio & Headphones
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('products', { category: 'Smartwatches' })}
                  className="hover:text-white transition-colors"
                >
                  Smartwatches
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('products', { category: 'Gaming' })}
                  className="hover:text-white transition-colors"
                >
                  Gaming Gear
                </button>
              </li>
            </ul>
          </div>

          <div>
            <h5 className="text-xs font-semibold uppercase tracking-wider text-slate-400 mb-4">
              Store & Policies
            </h5>
            <ul className="space-y-2 text-sm text-slate-400">
              <li>Shipping & Delivery Rules</li>
              <li>Return & Refund Policy</li>
              <li>Terms of Service</li>
              <li>Privacy Guarantee</li>
              <li>Payment Security & GST</li>
            </ul>
          </div>

          <div>
            <h5 className="text-xs font-semibold uppercase tracking-wider text-slate-400 mb-4">
              Testing & QA
            </h5>
            <p className="text-xs text-slate-400 leading-relaxed mb-3">
              Application verification environment for automated test agents and triage engineers.
            </p>
            <button
              onClick={() => onNavigate('qa')}
              className="text-xs font-medium text-amber-400 hover:text-amber-300 underline underline-offset-4"
            >
              Open QA Diagnostic Suite →
            </button>
          </div>
        </div>

        <div className="border-t border-slate-800 mt-12 pt-8 flex flex-col sm:flex-row items-center justify-between text-xs text-slate-500 gap-4">
          <span>© 2026 NexPulse Electronics Inc. All rights reserved.</span>
          <div className="flex items-center gap-6">
            <span>Prices in Indian Rupees (₹)</span>
            <span>All Taxes Included</span>
          </div>
        </div>
      </div>
    </footer>
  );
};
