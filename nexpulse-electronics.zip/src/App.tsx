import React, { useState, useEffect } from 'react';
import { CartProvider, useCart } from './context/CartContext';
import { Navbar } from './components/Navbar';
import { Footer } from './components/Footer';
import { HomePage } from './pages/HomePage';
import { ProductsPage } from './pages/ProductsPage';
import { ProductDetailPage } from './pages/ProductDetailPage';
import { CartPage } from './pages/CartPage';
import { CheckoutPage } from './pages/CheckoutPage';
import { OrderConfirmationPage } from './pages/OrderConfirmationPage';
import { QADashboardPage } from './pages/QADashboardPage';
import { productService } from './services/productService';
import { Product } from './types';

type ViewMode =
  | 'home'
  | 'products'
  | 'product-detail'
  | 'cart'
  | 'checkout'
  | 'order-confirmation'
  | 'qa';

function AppContent() {
  const [currentView, setCurrentView] = useState<ViewMode>('home');
  const [selectedProductId, setSelectedProductId] = useState<string>('prod-phone-1');
  const [activeCategoryFilter, setActiveCategoryFilter] = useState<string>('all');
  const [activeSearchFilter, setActiveSearchFilter] = useState<string>('');
  const [completedOrderId, setCompletedOrderId] = useState<string | undefined>(undefined);

  // Sync hash routing with URL (e.g. #qa, #products, #cart)
  useEffect(() => {
    const handleHashChange = () => {
      const hash = window.location.hash.replace('#', '').toLowerCase();
      if (hash === 'qa') {
        setCurrentView('qa');
      } else if (hash === 'products') {
        setCurrentView('products');
      } else if (hash === 'cart') {
        setCurrentView('cart');
      } else if (hash === 'checkout') {
        setCurrentView('checkout');
      }
    };

    handleHashChange();
    window.addEventListener('hashchange', handleHashChange);
    return () => window.removeEventListener('hashchange', handleHashChange);
  }, []);

  // Navigation handler
  const handleNavigate = (view: string, params?: any) => {
    window.scrollTo({ top: 0, behavior: 'smooth' });

    if (view === 'products') {
      if (params?.category) setActiveCategoryFilter(params.category);
      if (params?.search !== undefined) setActiveSearchFilter(params.search);
      setCurrentView('products');
      window.location.hash = 'products';
    } else if (view === 'qa') {
      setCurrentView('qa');
      window.location.hash = 'qa';
    } else if (view === 'cart') {
      setCurrentView('cart');
      window.location.hash = 'cart';
    } else if (view === 'checkout') {
      setCurrentView('checkout');
      window.location.hash = 'checkout';
    } else if (view === 'home') {
      setCurrentView('home');
      window.location.hash = '';
    } else if (view === 'order-confirmation') {
      if (params?.orderId) setCompletedOrderId(params.orderId);
      setCurrentView('order-confirmation');
    }
  };

  const handleSelectProduct = (productId: string) => {
    setSelectedProductId(productId);
    setCurrentView('product-detail');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const selectedProduct: Product | undefined =
    productService.getProductById(selectedProductId) || productService.getAllProducts()[0];

  return (
    <div className="min-h-screen flex flex-col bg-slate-50 text-slate-900">
      {/* Top Navigation */}
      <Navbar
        currentView={currentView}
        onNavigate={handleNavigate}
        onSearchSubmit={(q) => handleNavigate('products', { search: q })}
      />

      {/* Main View Switcher */}
      <main className="flex-1">
        {currentView === 'home' && (
          <HomePage
            onNavigate={handleNavigate}
            onSelectProduct={handleSelectProduct}
          />
        )}

        {currentView === 'products' && (
          <ProductsPage
            initialCategory={activeCategoryFilter}
            initialSearch={activeSearchFilter}
            onSelectProduct={handleSelectProduct}
          />
        )}

        {currentView === 'product-detail' && selectedProduct && (
          <ProductDetailPage
            product={selectedProduct}
            onBack={() => handleNavigate('products')}
            onNavigateToCart={() => handleNavigate('cart')}
            onNavigateToCheckout={() => handleNavigate('checkout')}
          />
        )}

        {currentView === 'cart' && (
          <CartPage
            onContinueShopping={() => handleNavigate('products')}
            onProceedToCheckout={() => handleNavigate('checkout')}
            onSelectProduct={handleSelectProduct}
          />
        )}

        {currentView === 'checkout' && (
          <CheckoutPage
            onBackToCart={() => handleNavigate('cart')}
            onOrderSuccess={(orderId) =>
              handleNavigate('order-confirmation', { orderId })
            }
          />
        )}

        {currentView === 'order-confirmation' && (
          <OrderConfirmationPage
            orderId={completedOrderId}
            onContinueShopping={() => handleNavigate('home')}
          />
        )}

        {currentView === 'qa' && <QADashboardPage onNavigate={handleNavigate} />}
      </main>

      {/* Footer */}
      <Footer onNavigate={handleNavigate} />
    </div>
  );
}

export default function App() {
  return (
    <CartProvider>
      <AppContent />
    </CartProvider>
  );
}
